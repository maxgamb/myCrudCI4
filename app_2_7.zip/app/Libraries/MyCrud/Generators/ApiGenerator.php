<?php

declare(strict_types=1);

namespace App\Libraries\MyCrud\Generators;

/** Genera controller REST v1 e Resource di serializzazione. */
final class ApiGenerator
{
    use GeneratorTrait;

    public function generate(array $config, bool $force = false): array
    {
        $table = (string) $config['table'];
        $api = (string) $config['classes']['api'];
        $service = (string) $config['classes']['service'];
        $rules = (string) $config['classes']['rules'];
        $pk = (string) $config['primaryKey'];
        $resource = preg_replace('/ApiController$/', 'Resource', $api) ?: $api . 'Resource';

        $readable = [];
        $writable = [];
        $filterable = [];
        $sortable = [];
        foreach ($config['fields'] as $field) {
            $name = (string) $field['name'];
            $ui = (array) ($field['ui'] ?? []);
            $sensitive = !empty($ui['sensitive'])
                || preg_match('/password|passwd|secret|token|pin|api[_-]?key|private[_-]?key|chiave|cvv/i', $name) === 1;
            $primaryAuto = !empty($field['primary']) && !empty($field['autoIncrement']);
            if (!$sensitive) {
                $readable[] = $name;
            }
            if (!$primaryAuto && empty($field['attributes']['boolean']) || !$primaryAuto) {
                if (!$sensitive || str_contains(strtolower($name), 'password')) {
                    $writable[] = $name;
                }
            }
            if (!$sensitive && !empty($ui['searchable'])) {
                $filterable[] = $name;
            }
            if (!$sensitive && !empty($ui['sortable'])) {
                $sortable[] = $name;
            }
        }
        if (!in_array($pk, $readable, true)) {
            array_unshift($readable, $pk);
        }

        $readableCode = var_export(array_values(array_unique($readable)), true);
        $writableCode = var_export(array_values(array_unique($writable)), true);
        $filterableCode = var_export(array_values(array_unique($filterable)), true);
        $sortableCode = var_export(array_values(array_unique($sortable)), true);

        $resourceContent = <<<PHP
<?php

declare(strict_types=1);

namespace App\API\Resources;

/** Serializza la risorsa {$table} senza esporre campi sensibili. */
final class {$resource}
{
    private const READABLE = {$readableCode};
    private const WRITABLE = {$writableCode};
    private const FILTERABLE = {$filterableCode};
    private const SORTABLE = {$sortableCode};

    public static function make(object|array \$record): array
    {
        \$source = is_array(\$record) ? \$record : get_object_vars(\$record);
        return array_intersect_key(\$source, array_flip(self::READABLE));
    }

    public static function collection(array \$records): array
    {
        return array_map(static fn (object|array \$record): array => self::make(\$record), \$records);
    }

    public static function writableData(array \$data): array
    {
        return array_intersect_key(\$data, array_flip(self::WRITABLE));
    }

    public static function filterableFields(): array
    {
        return self::FILTERABLE;
    }

    public static function sortableFields(): array
    {
        return self::SORTABLE;
    }
}

PHP;

        $softMethods = !empty($config['features']['softDeletes']) ? <<<PHP

    public function trash()
    {
        try {
            return \$this->success({$resource}::collection(\$this->service->deletedList()));
        } catch (Throwable \$e) {
            return \$this->internalError(\$e);
        }
    }

    public function restore(int|string \$id)
    {
        try {
            \$this->service->restore(\$id);
            return \$this->success(['{$pk}' => \$id, 'restored' => true]);
        } catch (Throwable \$e) {
            return \$this->error('RESTORE_FAILED', \$e->getMessage(), 400);
        }
    }

    public function forceDelete(int|string \$id)
    {
        try {
            \$this->service->forceDelete(\$id);
            return \$this->response->setStatusCode(204);
        } catch (Throwable \$e) {
            return \$this->error('DELETE_FAILED', \$e->getMessage(), 400);
        }
    }
PHP : '';

        $controllerContent = <<<PHP
<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\{$resource};
use App\Controllers\Api\BaseApiController;
use App\Services\{$service};
use App\Validation\{$rules};
use Throwable;

/** API REST v1 per la risorsa {$table}. */
final class {$api} extends BaseApiController
{
    public function __construct(private readonly {$service} \$service = new {$service}())
    {
    }

    public function index()
    {
        try {
            \$query = (array) \$this->request->getGet();
            \$query['perPage'] = \$this->safePerPage();
            \$result = \$this->service->apiList(\$query, {$resource}::filterableFields(), {$resource}::sortableFields());
            return \$this->success({$resource}::collection(\$result['rows']), \$result['meta'], \$result['links']);
        } catch (Throwable \$e) {
            return \$this->internalError(\$e);
        }
    }

    public function show(int|string \$id)
    {
        try {
            return \$this->success({$resource}::make(\$this->service->find(\$id)));
        } catch (Throwable \$e) {
            return \$this->error('NOT_FOUND', 'Record non trovato.', 404);
        }
    }

    public function create()
    {
        \$data = {$resource}::writableData(\$this->payload());
        if (!\$this->validateData(\$data, {$rules}::createRules(), {$rules}::messages())) {
            return \$this->error('VALIDATION_ERROR', 'Dati non validi.', 422, \$this->validator->getErrors());
        }
        try {
            \$id = \$this->service->create(\$data);
            return \$this->success(['{$pk}' => \$id], [], [], 201);
        } catch (Throwable \$e) {
            return \$this->error('CREATE_FAILED', \$e->getMessage(), 400);
        }
    }

    public function update(int|string \$id)
    {
        return \$this->writeUpdate(\$id, false);
    }

    public function patch(int|string \$id)
    {
        return \$this->writeUpdate(\$id, true);
    }

    private function writeUpdate(int|string \$id, bool \$partial)
    {
        \$data = {$resource}::writableData(\$this->payload());
        \$rules = {$rules}::updateRules(\$id);
        if (\$partial) {
            \$rules = array_intersect_key(\$rules, \$data);
        }
        if (\$rules !== [] && !\$this->validateData(\$data, \$rules, {$rules}::messages())) {
            return \$this->error('VALIDATION_ERROR', 'Dati non validi.', 422, \$this->validator->getErrors());
        }
        try {
            \$this->service->update(\$id, \$data);
            return \$this->success({$resource}::make(\$this->service->find(\$id)));
        } catch (Throwable \$e) {
            return \$this->error('UPDATE_FAILED', \$e->getMessage(), 400);
        }
    }

    public function delete(int|string \$id)
    {
        try {
            \$this->service->delete(\$id);
            return \$this->response->setStatusCode(204);
        } catch (Throwable \$e) {
            return \$this->error('DELETE_FAILED', \$e->getMessage(), 400);
        }
    }{$softMethods}
}

PHP;

        return [
            'controller' => $this->writeGenerated("Controllers/Api/V1/{$api}.php", $controllerContent, $force),
            'resource' => $this->writeGenerated("API/Resources/{$resource}.php", $resourceContent, $force),
        ];
    }
}
