<?php

declare(strict_types=1);

namespace App\Libraries\MyCrud\Generators;

/** Genera una specifica OpenAPI essenziale per la risorsa. */
final class OpenApiGenerator
{
    use GeneratorTrait;

    public function generate(array $config, bool $force = false): array
    {
        $table = (string) $config['table'];
        $pk = (string) $config['primaryKey'];
        $schema = [];
        foreach ($config['fields'] as $field) {
            $name = (string) $field['name'];
            $ui = (array) ($field['ui'] ?? []);
            if (!empty($ui['sensitive']) || preg_match('/password|secret|token|pin|key|chiave|cvv/i', $name)) {
                continue;
            }
            $type = strtolower((string) ($field['type'] ?? 'string'));
            $openType = preg_match('/int/', $type) ? 'integer' : (preg_match('/decimal|float|double/', $type) ? 'number' : (preg_match('/bool|tinyint/', $type) ? 'boolean' : 'string'));
            $schema[] = "        {$name}:\n          type: {$openType}";
        }
        $properties = implode("\n", $schema);
        $content = <<<YAML
openapi: 3.0.3
info:
  title: {$table} API
  version: 1.0.0
paths:
  /api/v1/{$table}:
    get:
      summary: Elenco {$table}
      parameters:
        - { name: page, in: query, schema: { type: integer, minimum: 1 } }
        - { name: perPage, in: query, schema: { type: integer, minimum: 1, maximum: 100 } }
        - { name: search, in: query, schema: { type: string } }
        - { name: sort, in: query, schema: { type: string } }
        - { name: direction, in: query, schema: { type: string, enum: [asc, desc] } }
      responses:
        '200': { description: Elenco paginato }
    post:
      summary: Crea record
      responses:
        '201': { description: Record creato }
        '422': { description: Errore di validazione }
  /api/v1/{$table}/{id}:
    parameters:
      - { name: id, in: path, required: true, schema: { type: string } }
    get:
      summary: Dettaglio record
      responses:
        '200': { description: Record trovato }
        '404': { description: Record non trovato }
    put:
      summary: Aggiornamento completo
      responses:
        '200': { description: Record aggiornato }
    patch:
      summary: Aggiornamento parziale
      responses:
        '200': { description: Record aggiornato }
    delete:
      summary: Elimina record
      responses:
        '204': { description: Record eliminato }
components:
  schemas:
    {$table}:
      type: object
      properties:
{$properties}
YAML;
        return $this->writeGenerated("OpenApi/{$table}.yaml", $content, $force);
    }
}
