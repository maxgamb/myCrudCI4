<?php

declare(strict_types=1);

namespace App\Libraries\Dashboard;

use App\DTO\Dashboard\SeriesPoint;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Database\BaseConnection;
use InvalidArgumentException;

/**
 * Dashboard-only aggregate query layer.
 *
 * Normal record retrieval stays in generated CRUD Models/Entities.
 */
final class DashboardQuery
{
    public function __construct(private ?BaseConnection $db = null)
    {
        $this->db ??= db_connect();
    }

    public function count(string $table, array $filter = []): int
    {
        $this->assertIdentifier($table);

        $builder = $this->db->table($table);
        $this->applyFilter($builder, $filter);

        return (int) $builder->countAllResults();
    }

    public function aggregate(
        string $table,
        string $field,
        string $operation,
        array $filter = []
    ): float {
        $this->assertIdentifier($table);
        $this->assertIdentifier($field);

        $operation = strtoupper($operation);
        if (!in_array($operation, ['SUM', 'AVG', 'MIN', 'MAX'], true)) {
            throw new InvalidArgumentException('Unsupported Dashboard aggregate.');
        }

        $builder = $this->db->table($table);
        $this->applyFilter($builder, $filter);

        $alias = 'dashboard_value';

        match ($operation) {
            'SUM' => $builder->selectSum($field, $alias),
            'AVG' => $builder->selectAvg($field, $alias),
            'MIN' => $builder->selectMin($field, $alias),
            'MAX' => $builder->selectMax($field, $alias),
        };

        $row = $builder->get()->getRowArray();

        return (float) ($row[$alias] ?? 0);
    }

    /**
     * @return list<SeriesPoint>
     */
    public function grouped(
        string $table,
        string $groupField,
        string $operation = 'COUNT',
        string $valueField = '',
        int $limit = 20,
        array $filter = []
    ): array {
        $this->assertIdentifier($table);
        $this->assertIdentifier($groupField);

        $operation = strtoupper($operation);
        if (!in_array($operation, ['COUNT', 'SUM', 'AVG', 'MIN', 'MAX'], true)) {
            throw new InvalidArgumentException('Unsupported Dashboard grouped operation.');
        }

        if ($operation !== 'COUNT') {
            $this->assertIdentifier($valueField);
        }

        $builder = $this->db->table($table);
        $this->applyFilter($builder, $filter);
        $builder->select($groupField . ' AS dashboard_label');

        if ($operation === 'COUNT') {
            $builder->select('COUNT(*) AS dashboard_value', false);
        } else {
            $alias = 'dashboard_value';
            match ($operation) {
                'SUM' => $builder->selectSum($valueField, $alias),
                'AVG' => $builder->selectAvg($valueField, $alias),
                'MIN' => $builder->selectMin($valueField, $alias),
                'MAX' => $builder->selectMax($valueField, $alias),
            };
        }

        $rows = $builder
            ->groupBy($groupField)
            ->orderBy('dashboard_value', 'DESC', false)
            ->limit(max(1, min(100, $limit)))
            ->get()
            ->getResultArray();

        $points = [];
        foreach ($rows as $row) {
            $label = $row['dashboard_label'] ?? null;
            $points[] = new SeriesPoint(
                $label === null || $label === '' ? '(empty)' : (string) $label,
                (float) ($row['dashboard_value'] ?? 0)
            );
        }

        return $points;
    }

    private function applyFilter(BaseBuilder $builder, array $filter): void
    {
        $field = trim((string) ($filter['field'] ?? ''));
        $operator = (string) ($filter['operator'] ?? 'eq');
        $value = $filter['value'] ?? null;

        if ($field === '' || $value === null || $value === '') {
            return;
        }

        $this->assertIdentifier($field);

        match ($operator) {
            'eq' => $builder->where($field, $value),
            'neq' => $builder->where($field . ' !=', $value),
            'gt' => $builder->where($field . ' >', $value),
            'gte' => $builder->where($field . ' >=', $value),
            'lt' => $builder->where($field . ' <', $value),
            'lte' => $builder->where($field . ' <=', $value),
            'contains' => $builder->like($field, (string) $value, 'both'),
            'starts_with' => $builder->like($field, (string) $value, 'after'),
            default => throw new InvalidArgumentException('Unsupported Dashboard filter operator.'),
        };
    }

    private function assertIdentifier(string $identifier): void
    {
        if ($identifier === '' || preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D', $identifier) !== 1) {
            throw new InvalidArgumentException('Invalid Dashboard SQL identifier.');
        }
    }
}