<?php

declare(strict_types=1);

namespace App\API\Resources;

/** Serializes the sales_by_film_category resource according to Builder configuration. */
final class SalesByFilmCategoryResource
{
    private const READABLE = array (
  0 => 'category',
  1 => 'total_sales',
);
    private const WRITABLE = array (
);
    private const FILTERABLE = array (
);
    private const SORTABLE = array (
  0 => 'category',
);

    public static function make(object|array $record): array
    {
        if (is_array($record)) {
            $source = $record;
        } elseif (method_exists($record, 'toRawArray')) {
            $source = $record->toRawArray();
        } elseif (method_exists($record, 'toArray')) {
            $source = $record->toArray();
        } else {
            $source = get_object_vars($record);
        }

        return array_intersect_key($source, array_flip(self::READABLE));
    }

    public static function collection(array $records): array
    {
        return array_map(static fn (object|array $record): array => self::make($record), $records);
    }

    public static function filterableFields(): array
    {
        return self::FILTERABLE;
    }

    public static function sortableFields(): array
    {
        return self::SORTABLE;
    }
}
