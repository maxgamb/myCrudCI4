<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\ActorEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;
use RuntimeException;
use Throwable;


/**
 * Model for `actor`. Centralizes CRUD queries, filters, relations, and persistence.
 *
 * Convenzioni generate:
 * - no SQL query should be moved into the Controller;
 * - gli alias belongsTo leggibili sono esposti come <foreign_key>__label;
 * - hasMany e N:N dispongono di metodi dedicati facilmente personalizzabili;
 * - databaseManaged fields are not written by the application.
 */
final class ActorModel extends Model
{
    protected $table = 'actor';
    protected $primaryKey = 'actor_id';
    protected $returnType = ActorEntity::class;

    /** Schema whitelists used by cross-resource query reuse. */
    private const RESOURCE_FIELDS = array (
  0 => 'actor_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'last_update',
);
    private const RESOURCE_FIELD_TYPES = array (
  'actor_id' => 'smallint',
  'first_name' => 'varchar',
  'last_name' => 'varchar',
  'last_update' => 'timestamp',
);
    private const FOREIGN_KEY_FIELDS = array (
);
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
  0 => 'first_name',
  1 => 'last_name',
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'actor_id' => 
  array (
    'type' => 'smallint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'last_name' => 
  array (
    'type' => 'varchar',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'starts_with',
      3 => 'contains',
      4 => 'ends_with',
      5 => 'is_null',
      6 => 'not_null',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'actor_id',
  1 => 'last_name',
);
    private const EXPORT_FIELDS = array (
  0 => 'actor_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'last_update',
);
    private const PRIMARY_KEYS = array (
  0 => 'actor_id',
);
    private const RELATION_SEARCHES = array (
);
    private const RELATED_CREATES = array (
);
    private const RELATED_CREATE_RELATIONS = array (
);
    private const MANY_TO_MANY = array (
  'many__film_actor__actor_id' => 
  array (
    'pivotTable' => 'film_actor',
    'ownPivotField' => 'actor_id',
    'relatedTable' => 'film',
    'relatedPivotField' => 'film_id',
    'relatedKey' => 'film_id',
    'displayField' => 'title',
    'displayFields' => 
    array (
      0 => 'title',
    ),
    'createEnabled' => true,
    'editEnabled' => true,
    'createRelatedEnabled' => true,
  ),
);
    private const MANY_TO_MANY_RELATED_CREATES = array (
  'many__film_actor__actor_id' => 
  array (
    'table' => 'film',
    'key' => 'film_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'title',
      1 => 'description',
      2 => 'release_year',
      3 => 'language_id',
      4 => 'original_language_id',
      5 => 'rental_duration',
      6 => 'rental_rate',
      7 => 'length',
      8 => 'replacement_cost',
      9 => 'rating',
      10 => 'special_features',
      11 => 'uploads',
    ),
    'nullableFields' => 
    array (
      0 => 'description',
      1 => 'release_year',
      2 => 'original_language_id',
      3 => 'length',
      4 => 'rating',
      5 => 'special_features',
      6 => 'uploads',
    ),
    'defaultedFields' => 
    array (
      0 => 'rental_duration',
      1 => 'rental_rate',
      2 => 'replacement_cost',
      3 => 'rating',
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
    'relations' => 
    array (
      'language_id' => 
      array (
        'table' => 'language',
        'key' => 'language_id',
        'displayField' => 'name',
        'mode' => 'select',
      ),
      'original_language_id' => 
      array (
        'table' => 'language',
        'key' => 'language_id',
        'displayField' => 'name',
        'mode' => 'select',
      ),
    ),
  ),
);
    private const COUNT_CACHE_SECONDS = 60;

    /**
     * Builds the full query used by detail and API.
     *
     * @return BaseBuilder Builder pronto per ulteriori condizioni.
     */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('actor');
        $builder->select([
            'actor.actor_id AS actor_id',
            'actor.first_name AS first_name',
            'actor.last_name AS last_name',
            'actor.last_update AS last_update'
        ]);

        return $builder;
    }

    /**
     * Builds the lightweight query used by the AJAX/paginated list.
     */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('actor');
        $builder->select([
            'actor.actor_id AS actor_id',
            'actor.first_name AS first_name',
            'actor.last_name AS last_name',
            'actor.last_update AS last_update'
        ]);

        return $builder;
    }

    /** Counts without JOINs so indexed filters remain inexpensive. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('actor');
        return $builder;
    }

    /** Returns the detail record with belongsTo labels already resolved. */
    public function getDetail(int|string $id): ?object
    {
        return $this->baseBuilder()
            ->where($this->table . '.' . $this->primaryKey, $id)
            ->get()
            ->getRow();
    }
    /**
     * Returns an HTML-ready page with the CI4 Pager.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows: array<int, object>, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'actor_id',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'actor_id';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('actor.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /**
     * Reads export records in chunks using the primary key as a stable cursor.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array<int, array<string, mixed>>
     */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('actor');
        $builder->select([
            'actor.actor_id AS actor_id',
            'actor.first_name AS first_name',
            'actor.last_name AS last_name',
            'actor.last_update AS last_update'
        ]);

        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('actor.actor_id >', $after);
        }

        return $builder
            ->orderBy('actor.actor_id', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /** Invalidates the list count cache after a write. */
    public function clearListCountCache(): void
    {
        service('cache')->delete('mycrud_list_total_' . md5($this->table));
    }
    /**
     * Applies the dynamic filter built by the site interface.
     * Field and operator are always checked against LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'actor.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Each condition is grouped so AND/OR behavior remains predictable even
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /**
     * Reusable option query for other generated resources.
     * All column names are checked against this Model's generated schema whitelist.
     *
     * @param list<string> $selectFields
     * @return list<array<string,mixed>>
     */
    public function relationOptionRows(
        string $key,
        array $selectFields,
        string $orderBy,
        string $query = '',
        ?string $id = null,
        int $limit = 500
    ): array {
        $allowed = array_fill_keys(self::RESOURCE_FIELDS, true);
        if (!isset($allowed[$key], $allowed[$orderBy])) {
            return [];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowed[$field])
        ));
        if ($selectFields === []) {
            $selectFields = [$key, $orderBy];
        }
        $builder = $this->db->table($this->table)
            ->select($selectFields)
            ->orderBy($orderBy, 'ASC')
            ->limit(max(1, min(5000, $limit)));
        if ($id !== null && $id !== '') {
            $builder->where($key, $id);
        } elseif (trim($query) !== '') {
            $builder->like($orderBy, trim($query), 'after');
        }
        return $builder->get()->getResultArray();
    }

    /**
     * Reusable child query. Only real FK fields of this resource may be used.
     *
     * @param list<string> $selectFields
     * @return array{rows:array<int,object>,count:int,hasMore:bool}
     */
    public function childrenByForeignKey(
        string $foreignKey,
        int|string $parentId,
        array $selectFields,
        string $orderBy,
        int $limit = 20
    ): array {
        $allowedFields = array_fill_keys(self::RESOURCE_FIELDS, true);
        $allowedForeignKeys = array_fill_keys(self::FOREIGN_KEY_FIELDS, true);
        if (!isset($allowedForeignKeys[$foreignKey], $allowedFields[$orderBy])) {
            return ['rows' => [], 'count' => 0, 'hasMore' => false];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowedFields[$field])
        ));
        if ($selectFields === []) {
            $selectFields = self::RESOURCE_FIELDS;
        }
        $selectExpressions = [];
        foreach ($selectFields as $field) {
            $type = strtolower((string) (self::RESOURCE_FIELD_TYPES[$field] ?? ''));
            if (in_array($type, ['point', 'geometry', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection'], true)) {
                $selectExpressions[] = 'ST_AsText(' . $this->db->protectIdentifiers($field) . ') AS ' . $this->db->protectIdentifiers($field);
            } else {
                $selectExpressions[] = $field;
            }
        }
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table($this->table)
            ->select($selectExpressions, false)
            ->where($foreignKey, $parentId)
            ->orderBy($orderBy, 'DESC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }
    /**
     * Inserts the current record and enabled atomic relations.
     *
     * @param array<string,mixed> $data
     * @param array<string,array<string,mixed>> $related
     * @param array<string,list<int|string>> $manyToMany
     * @param array<string,array<string,mixed>> $manyToManyNew
     * @return int|string
     * @throws RuntimeException|Throwable Se la persistenza non viene completata.
     */
    public function createRecord(
        array $data,
        array $related = [],
        array $manyToMany = [],
        array $manyToManyNew = []
    ): int|string {
        $this->db->transBegin();
        try {
            if ($manyToManyNew !== []) {
                $this->createManyToManyRelatedRecords($manyToManyNew, $manyToMany);
            }
            $id = $this->insert($data, true);
            if ($id === false) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Inserimento non riuscito.');
            }

            if ($manyToMany !== []) {
                $this->applyManyToMany((string) $id, $manyToMany, 'createEnabled');
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione di inserimento non riuscita.');
            }
            $this->db->transCommit();        } catch (Throwable $e) {
            $this->db->transRollback();            throw $e;
        }

        $this->clearListCountCache();
        return is_int($id) ? $id : (string) $id;
    }
    /**
     * Returns available options for form many-to-many selectors.
     *
     * @return array<string,list<array{id:string,text:string}>>
     */
    public function manyToManyFormOptions(): array
    {
        $result = [];
        foreach (self::MANY_TO_MANY as $key => $definition) {
            $table = (string) ($definition['relatedTable'] ?? '');
            $id = (string) ($definition['relatedKey'] ?? '');
            $label = (string) ($definition['displayField'] ?? $id);
            $labelFields = array_values(array_filter(array_map('strval', (array) ($definition['displayFields'] ?? []))));
            if ($labelFields === []) {
                $labelFields = [$label];
            }
            if ($table === '' || $id === '' || $label === '') {
                continue;
            }
            $selectFields = array_values(array_unique(array_merge([$id], $labelFields)));
            $rows = $this->db->table($table)
                ->select($selectFields)
                ->orderBy($labelFields[0], 'ASC')
                ->limit(500)
                ->get()
                ->getResultArray();
            $result[$key] = array_map(static function (array $row) use ($id, $labelFields): array {
                $parts = [];
                foreach ($labelFields as $field) {
                    $value = trim((string) ($row[$field] ?? ''));
                    if ($value !== '') {
                        $parts[] = $value;
                    }
                }
                return [
                    'id' => (string) ($row[$id] ?? ''),
                    'text' => $parts !== [] ? implode(' ', $parts) : (string) ($row[$id] ?? ''),
                ];
            }, $rows);
        }
        return $result;
    }
    /**
     * Options for foreign keys inside inline-created many-to-many targets.
     *
     * @return array<string,array<string,list<array{id:string,text:string}>>>
     */
    public function manyToManyRelatedCreateRelationOptions(): array
    {
        $result = [];

        foreach (self::MANY_TO_MANY_RELATED_CREATES as $relationKey => $definition) {
            foreach ((array) ($definition['relations'] ?? []) as $field => $relation) {
                if (($relation['mode'] ?? 'select') !== 'select') {
                    continue;
                }

                $table = (string) ($relation['table'] ?? '');
                $key = (string) ($relation['key'] ?? '');
                $display = (string) ($relation['displayField'] ?? '');
                if ($table === '' || $key === '' || $display === '') {
                    continue;
                }

                $rows = $this->db->table($table)
                    ->select([$key, $display])
                    ->orderBy($display, 'ASC')
                    ->limit(5000)
                    ->get()
                    ->getResultArray();

                foreach ($rows as $row) {
                    $result[(string) $relationKey][(string) $field][] = [
                        'id' => (string) ($row[$key] ?? ''),
                        'text' => (string) ($row[$display] ?? $row[$key] ?? ''),
                    ];
                }
            }
        }

        return $result;
    }
    /**
     * Returns IDs already associated with the record for each many-to-many relation.
     *
     * @return array<string,list<string>>
     */
    public function manyToManySelected(int|string $parentId): array
    {
        $result = [];
        foreach (self::MANY_TO_MANY as $key => $definition) {
            $pivot = (string) ($definition['pivotTable'] ?? '');
            $own = (string) ($definition['ownPivotField'] ?? '');
            $related = (string) ($definition['relatedPivotField'] ?? '');
            if ($pivot === '' || $own === '' || $related === '') {
                continue;
            }
            $rows = $this->db->table($pivot)
                ->select($related)
                ->where($own, $parentId)
                ->get()
                ->getResultArray();
            $result[$key] = array_map('strval', array_column($rows, $related));
        }
        return $result;
    }
    /**
     * Updates the record and synchronizes pure pivots in a single transaction.
     *
     * @param array<string,mixed> $data
     * @param array<string,list<int|string>> $manyToMany
     * @throws RuntimeException|Throwable
     */
    public function updateRecordWithManyToMany(
        int|string $id,
        array $data,
        array $manyToMany = [],
        array $manyToManyNew = []
    ): bool {
        $this->db->transBegin();
        try {
            if ($manyToManyNew !== []) {
                $this->createManyToManyRelatedRecords($manyToManyNew, $manyToMany);
            }
            if (!$this->update($id, $data)) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Update failed.');
            }
            if ($manyToMany !== []) {
                $this->applyManyToMany((string) $id, $manyToMany, 'editEnabled');
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione N:N non riuscita.');
            }
            $this->db->transCommit();
            $this->clearListCountCache();
            return true;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }
    /**
     * Valida gli ID target e sincronizza esclusivamente le righe pivot autorizzate.
     * Does not update or delete records from the target table.
     *
     * @param array<string,list<int|string>> $payload
     * @throws RuntimeException
     */
    private function applyManyToMany(int|string $parentId, array $payload, string $permission): void
    {
        foreach ($payload as $key => $ids) {
            $definition = self::MANY_TO_MANY[$key] ?? null;
            if (!is_array($definition) || empty($definition[$permission])) {
                continue;
            }
            $ids = is_array($ids) ? $ids : [];
            $ids = array_values(array_unique(array_map('strval', array_filter(
                $ids,
                static fn ($id): bool => is_scalar($id) && trim((string) $id) !== ''
            ))));
            if (count($ids) > 500) {
                throw new RuntimeException('Troppe associazioni N:N per ' . $key . '.');
            }

            $relatedTable = (string) ($definition['relatedTable'] ?? '');
            $relatedKey = (string) ($definition['relatedKey'] ?? '');
            if ($ids !== []) {
                $validRows = $this->db->table($relatedTable)
                    ->select($relatedKey)
                    ->whereIn($relatedKey, $ids)
                    ->get()
                    ->getResultArray();
                $valid = array_map('strval', array_column($validRows, $relatedKey));
                if (count(array_unique($valid)) !== count($ids)) {
                    throw new RuntimeException('One or more many-to-many records do not exist for ' . $key . '.');
                }
            }

            $pivot = (string) ($definition['pivotTable'] ?? '');
            $own = (string) ($definition['ownPivotField'] ?? '');
            $related = (string) ($definition['relatedPivotField'] ?? '');
            $existingRows = $this->db->table($pivot)
                ->select($related)
                ->where($own, $parentId)
                ->get()
                ->getResultArray();
            $existing = array_map('strval', array_column($existingRows, $related));
            foreach (array_diff($ids, $existing) as $attachId) {
                if (!$this->db->table($pivot)->insert([$own => $parentId, $related => $attachId])) {
                    throw new RuntimeException('Attach pivot non riuscito.');
                }
            }
            $detach = array_values(array_diff($existing, $ids));
            if ($detach !== []) {
                $this->db->table($pivot)->where($own, $parentId)->whereIn($related, $detach)->delete();
            }
        }
    }
    /**
     * Creates configured many-to-many target records and appends their IDs
     * to the association payload. The caller owns the surrounding transaction.
     *
     * @param array<string,array<string,mixed>> $newRecords
     * @param array<string,list<int|string>> $manyToMany
     */
    private function createManyToManyRelatedRecords(array $newRecords, array &$manyToMany): void
    {
        foreach ($newRecords as $relationKey => $data) {
            if (!is_array($data) || !isset(self::MANY_TO_MANY_RELATED_CREATES[$relationKey])) {
                continue;
            }

            $definition = self::MANY_TO_MANY_RELATED_CREATES[$relationKey];
            $allowed = array_fill_keys((array) ($definition['fields'] ?? []), true);
            $payload = array_intersect_key($data, $allowed);
            $nullable = array_fill_keys((array) ($definition['nullableFields'] ?? []), true);
            $defaulted = array_fill_keys((array) ($definition['defaultedFields'] ?? []), true);

            foreach ($payload as $field => $value) {
                if (!is_string($value) || trim($value) !== '') {
                    continue;
                }
                if (isset($defaulted[$field])) {
                    unset($payload[$field]);
                    continue;
                }
                if (isset($nullable[$field])) {
                    $payload[$field] = null;
                }
            }

            foreach ((array) ($definition['dateTimeFields'] ?? []) as $dateTimeField) {
                if (isset($payload[$dateTimeField]) && is_string($payload[$dateTimeField])) {
                    $payload[$dateTimeField] = str_replace('T', ' ', $payload[$dateTimeField]);
                }
            }

            $table = (string) ($definition['table'] ?? '');
            $key = (string) ($definition['key'] ?? '');
            if ($table === '' || $key === '') {
                throw new RuntimeException('Many-to-many related-create configuration is incomplete.');
            }

            foreach ((array) ($definition['relations'] ?? []) as $field => $relation) {
                if (!array_key_exists($field, $payload)) {
                    continue;
                }

                $value = $payload[$field];
                if ($value === null || (is_scalar($value) && trim((string) $value) === '')) {
                    continue;
                }

                $parentTable = (string) ($relation['table'] ?? '');
                $parentKey = (string) ($relation['key'] ?? '');
                if ($parentTable === '' || $parentKey === '') {
                    throw new RuntimeException('Nested relation configuration is incomplete for ' . $field . '.');
                }

                $exists = $this->db->table($parentTable)
                    ->select($parentKey)
                    ->where($parentKey, $value)
                    ->limit(1)
                    ->get()
                    ->getRowArray();

                if (!is_array($exists)) {
                    throw new RuntimeException('Invalid related value for ' . $field . '.');
                }
            }

            if (!$this->db->table($table)->insert($payload)) {
                throw new RuntimeException('Unable to create many-to-many related record: ' . $table . '.');
            }

            if (!empty($definition['keyAutoIncrement'])) {
                $newId = $this->db->insertID();
            } else {
                $newId = $payload[$key] ?? null;
            }

            if (!is_int($newId) && !is_string($newId)) {
                throw new RuntimeException('Created related record key is unavailable for ' . $table . '.');
            }
            if ((string) $newId === '' || (string) $newId === '0') {
                throw new RuntimeException('Created related record key is invalid for ' . $table . '.');
            }

            $manyToMany[(string) $relationKey] ??= [];
            $manyToMany[(string) $relationKey][] = $newId;
            $manyToMany[(string) $relationKey] = array_values(array_unique(
                array_map('strval', $manyToMany[(string) $relationKey])
            ));
        }
    }
    /** Paginated REST list with filter and sorting whitelists. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('actor.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'actor_id');
        $sort = in_array($sort, $sortable, true) ? $sort : 'actor_id';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('actor.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table film_actor.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getFilmActorByActorId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\FilmActorModel())->childrenByForeignKey(
            'actor_id',
            $parentId,
            array (
  0 => 'actor_id',
  1 => 'film_id',
  2 => 'last_update',
),
            'actor_id',
            $limit
        );
    }
    /**
     * Many-to-many scaffolding: reads film through pivot film_actor.
     * Punto di estensione: ampliare select/orderBy senza toccare il Controller.
     */
    public function getFilmViaFilmActor(int|string $parentId, int $limit = 20): array
    {
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table('film_actor p')
            ->select('r.film_id, r.title')
            ->join('film r', 'r.film_id = p.film_id', 'inner')
            ->where('p.actor_id', $parentId)
            ->orderBy('r.title', 'ASC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }

    /** Attach idempotente alla pivot film_actor. */
    public function attachFilm(int|string $parentId, int|string $relatedId): bool
    {
        $builder = $this->db->table('film_actor');
        $exists = $builder->where('actor_id', $parentId)
            ->where('film_id', $relatedId)
            ->countAllResults() > 0;
        return $exists || $this->db->table('film_actor')->insert([
            'actor_id' => $parentId,
            'film_id' => $relatedId,
        ]);
    }

    /** Rimuove una singola associazione dalla pivot film_actor. */
    public function detachFilm(int|string $parentId, int|string $relatedId): bool
    {
        return $this->db->table('film_actor')
            ->where('actor_id', $parentId)
            ->where('film_id', $relatedId)
            ->delete();
    }

    /**
     * Sincronizza le associazioni con un diff attach/detach.
     * Does not update or delete records from table film.
     */
    public function syncFilm(int|string $parentId, array $relatedIds): bool
    {
        $relatedIds = array_values(array_unique(array_map('strval', array_filter(
            $relatedIds,
            static fn (mixed $id): bool => is_scalar($id) && trim((string) $id) !== ''
        ))));
        $existingRows = $this->db->table('film_actor')
            ->select('film_id')
            ->where('actor_id', $parentId)
            ->get()->getResultArray();
        $existing = array_map('strval', array_column($existingRows, 'film_id'));
        $attach = array_values(array_diff($relatedIds, $existing));
        $detach = array_values(array_diff($existing, $relatedIds));

        $this->db->transBegin();
        try {
            foreach ($attach as $id) {
                if (!$this->attachFilm($parentId, $id)) {
                    throw new RuntimeException('Attach pivot non riuscito.');
                }
            }
            foreach ($detach as $id) {
                if (!$this->detachFilm($parentId, $id)) {
                    throw new RuntimeException('Detach pivot non riuscito.');
                }
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Sync pivot non riuscito.');
            }
            $this->db->transCommit();
            return true;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }
    /** @return array<string,array<string,mixed>> */
    public function loadHasMany(int|string $parentId): array
    {
        $result = [];
        $result['film_actor__actor_id'] = $this->getFilmActorByActorId($parentId, 20);

        $result['many__film_actor__actor_id'] = $this->getFilmViaFilmActor($parentId, 20);
        return $result;
    }
}
