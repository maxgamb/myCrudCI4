<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\SalesByStoreEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;


/**
 * Read-only Model for SQL VIEW `sales_by_store`. Centralizes read queries, filters, and export.
 *
 * Convenzioni generate:
 * - no SQL query should be moved into the Controller;
 * - gli alias belongsTo leggibili sono esposti come <foreign_key>__label;
 * - hasMany e N:N dispongono di metodi dedicati facilmente personalizzabili;
 * - databaseManaged fields are not written by the application.
 */
final class SalesByStoreModel extends Model
{
    protected $table = 'sales_by_store';
    protected $primaryKey = 'store';
    protected $returnType = SalesByStoreEntity::class;

    /** Schema whitelists used by cross-resource query reuse. */
    private const RESOURCE_FIELDS = array (
  0 => 'store',
  1 => 'manager',
  2 => 'total_sales',
);
    private const RESOURCE_FIELD_TYPES = array (
  'store' => 'varchar',
  'manager' => 'varchar',
  'total_sales' => 'decimal',
);
    private const FOREIGN_KEY_FIELDS = array (
);
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'store' => 
  array (
    'type' => 'primary',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'store',
);
    private const EXPORT_FIELDS = array (
  0 => 'store',
  1 => 'manager',
  2 => 'total_sales',
);
    private const PRIMARY_KEYS = array (
);
    private const RELATION_SEARCHES = array (
);
    private const RELATED_CREATES = array (
);
    private const RELATED_CREATE_RELATIONS = array (
);
    private const MANY_TO_MANY = array (
);
    private const MANY_TO_MANY_RELATED_CREATES = array (
);
    private const COUNT_CACHE_SECONDS = 60;

    /**
     * Builds the full query used by detail and API.
     *
     * @return BaseBuilder Builder pronto per ulteriori condizioni.
     */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('sales_by_store');
        $builder->select([
            'sales_by_store.store AS store',
            'sales_by_store.manager AS manager',
            'sales_by_store.total_sales AS total_sales'
        ]);

        return $builder;
    }

    /**
     * Builds the lightweight query used by the AJAX/paginated list.
     */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('sales_by_store');
        $builder->select([
            'sales_by_store.store AS store',
            'sales_by_store.manager AS manager',
            'sales_by_store.total_sales AS total_sales'
        ]);

        return $builder;
    }

    /** Counts without JOINs so indexed filters remain inexpensive. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('sales_by_store');
        return $builder;
    }

    /**
     * Returns an HTML-ready page with the CI4 Pager.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows: array<int, object>, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'store',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'store';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('sales_by_store.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /**
     * Reads export records in chunks using the primary key as a stable cursor.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array<int, array<string, mixed>>
     */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('sales_by_store');
        $builder->select([
            'sales_by_store.store AS store',
            'sales_by_store.manager AS manager',
            'sales_by_store.total_sales AS total_sales'
        ]);

        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('sales_by_store.store >', $after);
        }

        return $builder
            ->orderBy('sales_by_store.store', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * Applies the dynamic filter built by the site interface.
     * Field and operator are always checked against LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'sales_by_store.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Each condition is grouped so AND/OR behavior remains predictable even
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /**
     * Reusable option query for other generated resources.
     * All column names are checked against this Model's generated schema whitelist.
     *
     * @param list<string> $selectFields
     * @return list<array<string,mixed>>
     */
    public function relationOptionRows(
        string $key,
        array $selectFields,
        string $orderBy,
        string $query = '',
        ?string $id = null,
        int $limit = 500
    ): array {
        $allowed = array_fill_keys(self::RESOURCE_FIELDS, true);
        if (!isset($allowed[$key], $allowed[$orderBy])) {
            return [];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowed[$field])
        ));
        if ($selectFields === []) {
            $selectFields = [$key, $orderBy];
        }
        $builder = $this->db->table($this->table)
            ->select($selectFields)
            ->orderBy($orderBy, 'ASC')
            ->limit(max(1, min(5000, $limit)));
        if ($id !== null && $id !== '') {
            $builder->where($key, $id);
        } elseif (trim($query) !== '') {
            $builder->like($orderBy, trim($query), 'after');
        }
        return $builder->get()->getResultArray();
    }

    /**
     * Reusable child query. Only real FK fields of this resource may be used.
     *
     * @param list<string> $selectFields
     * @return array{rows:array<int,object>,count:int,hasMore:bool}
     */
    public function childrenByForeignKey(
        string $foreignKey,
        int|string $parentId,
        array $selectFields,
        string $orderBy,
        int $limit = 20
    ): array {
        $allowedFields = array_fill_keys(self::RESOURCE_FIELDS, true);
        $allowedForeignKeys = array_fill_keys(self::FOREIGN_KEY_FIELDS, true);
        if (!isset($allowedForeignKeys[$foreignKey], $allowedFields[$orderBy])) {
            return ['rows' => [], 'count' => 0, 'hasMore' => false];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowedFields[$field])
        ));
        if ($selectFields === []) {
            $selectFields = self::RESOURCE_FIELDS;
        }
        $selectExpressions = [];
        foreach ($selectFields as $field) {
            $type = strtolower((string) (self::RESOURCE_FIELD_TYPES[$field] ?? ''));
            if (in_array($type, ['point', 'geometry', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection'], true)) {
                $selectExpressions[] = 'ST_AsText(' . $this->db->protectIdentifiers($field) . ') AS ' . $this->db->protectIdentifiers($field);
            } else {
                $selectExpressions[] = $field;
            }
        }
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table($this->table)
            ->select($selectExpressions, false)
            ->where($foreignKey, $parentId)
            ->orderBy($orderBy, 'DESC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }
    /** Paginated REST list with filter and sorting whitelists. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('sales_by_store.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'store');
        $sort = in_array($sort, $sortable, true) ? $sort : 'store';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('sales_by_store.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
}
