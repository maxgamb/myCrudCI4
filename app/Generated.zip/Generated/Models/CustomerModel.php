<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\CustomerEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;
use RuntimeException;
use Throwable;


/**
 * Model for `customer`. Centralizes CRUD queries, filters, relations, and persistence.
 *
 * Convenzioni generate:
 * - no SQL query should be moved into the Controller;
 * - gli alias belongsTo leggibili sono esposti come <foreign_key>__label;
 * - hasMany e N:N dispongono di metodi dedicati facilmente personalizzabili;
 * - databaseManaged fields are not written by the application.
 */
final class CustomerModel extends Model
{
    protected $table = 'customer';
    protected $primaryKey = 'customer_id';
    protected $returnType = CustomerEntity::class;

    /** Schema whitelists used by cross-resource query reuse. */
    private const RESOURCE_FIELDS = array (
  0 => 'customer_id',
  1 => 'store_id',
  2 => 'first_name',
  3 => 'last_name',
  4 => 'email',
  5 => 'address_id',
  6 => 'active',
  7 => 'create_date',
  8 => 'last_update',
);
    private const RESOURCE_FIELD_TYPES = array (
  'customer_id' => 'smallint',
  'store_id' => 'tinyint',
  'first_name' => 'varchar',
  'last_name' => 'varchar',
  'email' => 'varchar',
  'address_id' => 'smallint',
  'active' => 'tinyint',
  'create_date' => 'datetime',
  'last_update' => 'timestamp',
);
    private const FOREIGN_KEY_FIELDS = array (
  0 => 'address_id',
  1 => 'store_id',
);
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
  0 => 'store_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'email',
  4 => 'address_id',
  5 => 'active',
  6 => 'create_date',
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'customer_id' => 
  array (
    'type' => 'smallint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'store_id' => 
  array (
    'type' => 'tinyint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'last_name' => 
  array (
    'type' => 'varchar',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'starts_with',
      3 => 'contains',
      4 => 'ends_with',
      5 => 'is_null',
      6 => 'not_null',
    ),
  ),
  'address_id' => 
  array (
    'type' => 'smallint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'customer_id',
  1 => 'store_id',
  2 => 'last_name',
  3 => 'address_id',
);
    private const EXPORT_FIELDS = array (
  0 => 'customer_id',
  1 => 'store_id',
  2 => 'first_name',
  3 => 'last_name',
  4 => 'email',
  5 => 'address_id',
  6 => 'active',
  7 => 'create_date',
  8 => 'last_update',
);
    private const PRIMARY_KEYS = array (
  0 => 'customer_id',
);
    private const RELATION_SEARCHES = array (
  'address_id' => 
  array (
    'table' => 'address',
    'key' => 'address_id',
    'displayField' => 'address',
    'displayTemplate' => '{{address}} {{district}} {{postal_code}}',
    'displayFields' => 
    array (
      0 => 'address',
      1 => 'district',
      2 => 'postal_code',
    ),
    'mode' => 'ajax',
  ),
  'store_id' => 
  array (
    'table' => 'store',
    'key' => 'store_id',
    'displayField' => 'store_id',
    'displayTemplate' => '',
    'displayFields' => 
    array (
      0 => 'store_id',
    ),
    'mode' => 'select',
  ),
);
    private const RELATED_CREATES = array (
  'address_id' => 
  array (
    'table' => 'address',
    'key' => 'address_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'address',
      1 => 'address2',
      2 => 'district',
      3 => 'city_id',
      4 => 'postal_code',
      5 => 'phone',
      6 => 'location',
    ),
    'nullableFields' => 
    array (
      0 => 'address2',
      1 => 'postal_code',
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
      0 => 'location',
    ),
  ),
  'store_id' => 
  array (
    'table' => 'store',
    'key' => 'store_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'manager_staff_id',
      1 => 'address_id',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
  ),
);
    private const RELATED_CREATE_RELATIONS = array (
  'address_id' => 
  array (
    'city_id' => 
    array (
      'table' => 'city',
      'key' => 'city_id',
      'displayField' => 'city',
      'mode' => 'select',
      'uniqueConsumerTable' => '',
      'uniqueConsumerField' => '',
    ),
  ),
  'store_id' => 
  array (
    'manager_staff_id' => 
    array (
      'table' => 'staff',
      'key' => 'staff_id',
      'displayField' => 'first_name',
      'mode' => 'select',
      'uniqueConsumerTable' => 'store',
      'uniqueConsumerField' => 'manager_staff_id',
    ),
    'address_id' => 
    array (
      'table' => 'address',
      'key' => 'address_id',
      'displayField' => 'address',
      'mode' => 'select',
      'uniqueConsumerTable' => '',
      'uniqueConsumerField' => '',
    ),
  ),
);
    private const MANY_TO_MANY = array (
);
    private const MANY_TO_MANY_RELATED_CREATES = array (
);
    private const COUNT_CACHE_SECONDS = 60;

    /**
     * Builds the full query used by detail and API.
     *
     * @return BaseBuilder Builder pronto per ulteriori condizioni.
     */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('customer');
        $builder->select([
            'customer.customer_id AS customer_id',
            'customer.store_id AS store_id',
            'customer.first_name AS first_name',
            'customer.last_name AS last_name',
            'customer.email AS email',
            'customer.address_id AS address_id',
            'customer.active AS active',
            'customer.create_date AS create_date',
            'customer.last_update AS last_update',
            'TRIM(CONCAT(\'{\', COALESCE(CAST(address__address_id.address AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.district AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.postal_code AS CHAR), \'\'), \'}\')) AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        return $builder;
    }

    /**
     * Builds the lightweight query used by the AJAX/paginated list.
     */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('customer');
        $builder->select([
            'customer.customer_id AS customer_id',
            'customer.store_id AS store_id',
            'customer.first_name AS first_name',
            'customer.last_name AS last_name',
            'customer.email AS email',
            'customer.address_id AS address_id',
            'customer.active AS active',
            'customer.create_date AS create_date',
            'customer.last_update AS last_update',
            'TRIM(CONCAT(\'{\', COALESCE(CAST(address__address_id.address AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.district AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.postal_code AS CHAR), \'\'), \'}\')) AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        return $builder;
    }

    /** Counts without JOINs so indexed filters remain inexpensive. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('customer');
        return $builder;
    }

    /** Returns the detail record with belongsTo labels already resolved. */
    public function getDetail(int|string $id): ?object
    {
        return $this->baseBuilder()
            ->where($this->table . '.' . $this->primaryKey, $id)
            ->get()
            ->getRow();
    }
    /**
     * Returns an HTML-ready page with the CI4 Pager.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows: array<int, object>, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'customer_id',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'customer_id';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('customer.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /**
     * Reads export records in chunks using the primary key as a stable cursor.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array<int, array<string, mixed>>
     */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('customer');
        $builder->select([
            'customer.customer_id AS customer_id',
            'customer.store_id AS store_id',
            'customer.first_name AS first_name',
            'customer.last_name AS last_name',
            'customer.email AS email',
            'customer.address_id AS address_id',
            'customer.active AS active',
            'customer.create_date AS create_date',
            'customer.last_update AS last_update',
            'TRIM(CONCAT(\'{\', COALESCE(CAST(address__address_id.address AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.district AS CHAR), \'\'), \'} {\', COALESCE(CAST(address__address_id.postal_code AS CHAR), \'\'), \'}\')) AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('customer.customer_id >', $after);
        }

        return $builder
            ->orderBy('customer.customer_id', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /** Invalidates the list count cache after a write. */
    public function clearListCountCache(): void
    {
        service('cache')->delete('mycrud_list_total_' . md5($this->table));
    }
    /**
     * Applies the dynamic filter built by the site interface.
     * Field and operator are always checked against LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'customer.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Each condition is grouped so AND/OR behavior remains predictable even
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /**
     * Reusable option query for other generated resources.
     * All column names are checked against this Model's generated schema whitelist.
     *
     * @param list<string> $selectFields
     * @return list<array<string,mixed>>
     */
    public function relationOptionRows(
        string $key,
        array $selectFields,
        string $orderBy,
        string $query = '',
        ?string $id = null,
        int $limit = 500
    ): array {
        $allowed = array_fill_keys(self::RESOURCE_FIELDS, true);
        if (!isset($allowed[$key], $allowed[$orderBy])) {
            return [];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowed[$field])
        ));
        if ($selectFields === []) {
            $selectFields = [$key, $orderBy];
        }
        $builder = $this->db->table($this->table)
            ->select($selectFields)
            ->orderBy($orderBy, 'ASC')
            ->limit(max(1, min(5000, $limit)));
        if ($id !== null && $id !== '') {
            $builder->where($key, $id);
        } elseif (trim($query) !== '') {
            $builder->like($orderBy, trim($query), 'after');
        }
        return $builder->get()->getResultArray();
    }

    /**
     * Reusable child query. Only real FK fields of this resource may be used.
     *
     * @param list<string> $selectFields
     * @return array{rows:array<int,object>,count:int,hasMore:bool}
     */
    public function childrenByForeignKey(
        string $foreignKey,
        int|string $parentId,
        array $selectFields,
        string $orderBy,
        int $limit = 20
    ): array {
        $allowedFields = array_fill_keys(self::RESOURCE_FIELDS, true);
        $allowedForeignKeys = array_fill_keys(self::FOREIGN_KEY_FIELDS, true);
        if (!isset($allowedForeignKeys[$foreignKey], $allowedFields[$orderBy])) {
            return ['rows' => [], 'count' => 0, 'hasMore' => false];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowedFields[$field])
        ));
        if ($selectFields === []) {
            $selectFields = self::RESOURCE_FIELDS;
        }
        $selectExpressions = [];
        foreach ($selectFields as $field) {
            $type = strtolower((string) (self::RESOURCE_FIELD_TYPES[$field] ?? ''));
            if (in_array($type, ['point', 'geometry', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection'], true)) {
                $selectExpressions[] = 'ST_AsText(' . $this->db->protectIdentifiers($field) . ') AS ' . $this->db->protectIdentifiers($field);
            } else {
                $selectExpressions[] = $field;
            }
        }
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table($this->table)
            ->select($selectExpressions, false)
            ->where($foreignKey, $parentId)
            ->orderBy($orderBy, 'DESC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }
    /**
     * Inserts the current record and enabled atomic relations.
     *
     * @param array<string,mixed> $data
     * @param array<string,array<string,mixed>> $related
     * @param array<string,list<int|string>> $manyToMany
     * @param array<string,array<string,mixed>> $manyToManyNew
     * @return int|string
     * @throws RuntimeException|Throwable Se la persistenza non viene completata.
     */
    public function createRecord(
        array $data,
        array $related = [],
        array $manyToMany = [],
        array $manyToManyNew = []
    ): int|string {
        $this->db->transBegin();
        try {
            foreach ($related as $field => $payload) {
                if (!is_array($payload) || !isset(self::RELATED_CREATES[$field])) {
                    continue;
                }
                $data[$field] = $this->createRelatedRecord((string) $field, $payload);
            }
            $id = $this->insert($data, true);
            if ($id === false) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Inserimento non riuscito.');
            }

            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione di inserimento non riuscita.');
            }
            $this->db->transCommit();        } catch (Throwable $e) {
            $this->db->transRollback();            throw $e;
        }

        $this->clearListCountCache();
        return is_int($id) ? $id : (string) $id;
    }
    /**
     * Updates the current record.
     *
     * @param array<string,mixed> $data
     */
    public function updateRecordWithManyToMany(
        int|string $id,
        array $data,
        array $manyToMany = [],
        array $manyToManyNew = []
    ): bool {
        if ($manyToManyNew !== []) {
            throw new RuntimeException('Many-to-many related creation is not available for this CRUD.');
        }
        if (!$this->update($id, $data)) {
            return false;
        }

        $this->clearListCountCache();
        return true;
    }
    /**
     * Creates a single parent record authorized by generated configuration.
     *
     * @param array<string,mixed> $data
     * @return int|string
     * @throws RuntimeException
     */
    private function createRelatedRecord(string $field, array $data): int|string
    {
        $definition = self::RELATED_CREATES[$field] ?? null;
        if (!is_array($definition)) {
            throw new RuntimeException('Related-record creation is not authorized for ' . $field . '.');
        }

        $allowed = array_fill_keys((array) ($definition['fields'] ?? []), true);
        $payload = array_intersect_key($data, $allowed);
        $nullable = array_fill_keys((array) ($definition['nullableFields'] ?? []), true);
        $defaulted = array_fill_keys((array) ($definition['defaultedFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!is_string($payloadValue) || trim($payloadValue) !== '') {
                continue;
            }
            if (isset($defaulted[$payloadField])) {
                unset($payload[$payloadField]);
                continue;
            }
            if (isset($nullable[$payloadField])) {
                $payload[$payloadField] = null;
            }
        }

        foreach ((array) ($definition['dateTimeFields'] ?? []) as $dateTimeField) {
            if (isset($payload[$dateTimeField]) && is_string($payload[$dateTimeField])) {
                $payload[$dateTimeField] = str_replace('T', ' ', $payload[$dateTimeField]);
            }
        }

        $table = (string) ($definition['table'] ?? '');
        $key = (string) ($definition['key'] ?? '');
        if ($table === '' || $key === '') {
            throw new RuntimeException('Related-record configuration is incomplete.');
        }
        $builder = $this->db->table($table);
        $spatialFields = array_fill_keys((array) ($definition['spatialFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!isset($spatialFields[$payloadField])) {
                $builder->set($payloadField, $payloadValue);
                continue;
            }

            $wkt = trim((string) $payloadValue);
            if ($wkt === '') {
                throw new RuntimeException('Spatial value is required for ' . $payloadField . '.');
            }
            // WKT is escaped as a value; only the trusted SQL function is raw.
            $builder->set($payloadField, 'ST_GeomFromText(' . $this->db->escape($wkt) . ')', false);
        }
        if (!$builder->insert()) {
            $dbError = (array) $this->db->error();
            $dbCode = trim((string) ($dbError['code'] ?? ''));
            $dbMessage = trim((string) ($dbError['message'] ?? ''));
            $detail = $dbMessage !== ''
                ? ' Database error' . ($dbCode !== '' ? ' [' . $dbCode . ']' : '') . ': ' . $dbMessage
                : '';
            log_message('error', 'Related Create insert failed for {table}: {code} {message}', [
                'table' => $table,
                'code' => $dbCode,
                'message' => $dbMessage,
            ]);
            throw new RuntimeException('Unable to insert related record: ' . $table . '.' . $detail);
        }

        if (!empty($definition['keyAutoIncrement'])) {
            $id = $this->db->insertID();
            if ($id === 0 || $id === '0' || $id === '') {
                throw new RuntimeException('Generated key is not available for ' . $table . '.');
            }
            return is_int($id) ? $id : (string) $id;
        }

        $id = $payload[$key] ?? null;
        if (!is_int($id) && !is_string($id)) {
            throw new RuntimeException('The related-record key must have a value: ' . $key . '.');
        }

        return $id;
    }
    /** FK customer.address_id -> address.address_id; risultato: address_id__label. */
    private function joinAddressAddressId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'address AS address__address_id',
            'address__address_id.address_id = customer.address_id',
            'left'
        );

        return $builder;
    }
    /** FK customer.store_id -> store.store_id; risultato: store_id__label. */
    private function joinStoreStoreId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'store AS store__store_id',
            'store__store_id.store_id = customer.store_id',
            'left'
        );

        return $builder;
    }
    /** Paginated REST list with filter and sorting whitelists. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('customer.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'customer_id');
        $sort = in_array($sort, $sortable, true) ? $sort : 'customer_id';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('customer.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
    /** Returns options for the store_id relation through the owning parent Model. */
    public function getStoreStoreIdOptions(): array
    {
        return (new \App\Models\StoreModel())->relationOptionRows(
            'store_id',
            array (
  0 => 'store_id',
),
            'store_id'
        );
    }
    /**
     * Options for foreign keys belonging to inline-created parents.
     * La whitelist deriva esclusivamente dalle FK reali dello schema.
     *
     * @return array<string,array<string,list<array{id:string,text:string}>>>
     */
    public function relatedCreateRelationOptions(): array
    {
        $result = [];
        foreach (self::RELATED_CREATE_RELATIONS as $relationField => $fields) {
            foreach ((array) $fields as $field => $definition) {
                if (($definition['mode'] ?? 'select') !== 'select') {
                    continue;
                }
                $table = (string) $definition['table'];
                $key = (string) $definition['key'];
                $display = (string) $definition['displayField'];
                $builder = $this->db->table($table)
                    ->select([$key, $display])
                    ->orderBy($display, 'ASC');

                // If this FK is UNIQUE in the inline-created table, choices
                // already referenced there would necessarily fail validation
                // (and the database constraint). Hide them before rendering
                // the Related Create select instead of asking the user to
                // discover the conflict after submit.
                $consumerTable = trim((string) ($definition['uniqueConsumerTable'] ?? ''));
                $consumerField = trim((string) ($definition['uniqueConsumerField'] ?? ''));
                if ($consumerTable !== '' && $consumerField !== '') {
                    $usedRows = $this->db->table($consumerTable)
                        ->select($consumerField)
                        ->where($consumerField . ' IS NOT NULL', null, false)
                        ->get()
                        ->getResultArray();
                    $usedIds = array_values(array_unique(array_filter(
                        array_map(
                            static fn (array $row): string => (string) ($row[$consumerField] ?? ''),
                            $usedRows
                        ),
                        static fn (string $value): bool => $value !== ''
                    )));
                    if ($usedIds !== []) {
                        $builder->whereNotIn($key, $usedIds);
                    }
                }

                $rows = $builder->get()->getResultArray();
                foreach ($rows as $row) {
                    $result[(string) $relationField][(string) $field][] = [
                        'id' => (string) ($row[$key] ?? ''),
                        'text' => (string) ($row[$display] ?? $row[$key] ?? ''),
                    ];
                }
            }
        }
        return $result;
    }
    /** @return array<string,array<string,string>> */
    public function relationOptions(): array
    {
        return [
            'store_id' => $this->toRelationOptions($this->getStoreStoreIdOptions(), 'store_id'),
        ];
    }

    /**
     * Server-side option search for large relations.
     * Table, key, and descriptive fields come only from the generated whitelist.
     *
     * @return list<array{id:string,text:string}>
     */
    public function searchRelationOptions(string $field, string $query, int $limit = 20): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $limit = max(1, min(100, $limit));
        $builder = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->orderBy((string) $definition['displayField'], 'ASC')
            ->limit($limit);

        $query = trim($query);
        if ($query !== '' && $displayFields !== []) {
            $builder->groupStart();
            foreach ($displayFields as $index => $displayColumn) {
                if ($index === 0) {
                    $builder->like((string) $displayColumn, $query, 'after');
                } else {
                    $builder->orLike((string) $displayColumn, $query, 'after');
                }
            }
            $builder->groupEnd();
        }

        $rows = $builder->get()->getResultArray();
        $result = [];
        foreach ($rows as $row) {
            $result[] = [
                'id' => (string) ($row[$key] ?? ''),
                'text' => $this->formatRelationLabel($row, $definition),
            ];
        }

        return $result;
    }

    /** @return array{id:string,text:string}|null */
    public function relationOptionById(string $field, int|string $id): ?array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return null;
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $row = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->where($key, $id)
            ->limit(1)
            ->get()
            ->getRowArray();

        if (!is_array($row)) {
            return null;
        }

        return [
            'id' => (string) ($row[$key] ?? ''),
            'text' => $this->formatRelationLabel($row, $definition),
        ];
    }

    /** @return array<string,string> */
    private function toRelationOptions(array $rows, string $field): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $options = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $options[(string) ($row[$key] ?? '')] = $this->formatRelationLabel($row, $definition);
        }
        return $options;
    }

    private function formatRelationLabel(array $row, array $definition): string
    {
        $template = trim((string) ($definition['displayTemplate'] ?? ''));
        if ($template === '') {
            return trim((string) ($row[(string) $definition['displayField']] ?? ''));
        }

        $label = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/',
            static fn (array $match): string => (string) ($row[$match[1]] ?? ''),
            $template
        );

        return trim((string) $label);
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table payment.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getPaymentByCustomerId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\PaymentModel())->childrenByForeignKey(
            'customer_id',
            $parentId,
            array (
  0 => 'payment_id',
  1 => 'customer_id',
  2 => 'staff_id',
  3 => 'rental_id',
  4 => 'amount',
  5 => 'payment_date',
  6 => 'last_update',
),
            'payment_id',
            $limit
        );
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table rental.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getRentalByCustomerId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\RentalModel())->childrenByForeignKey(
            'customer_id',
            $parentId,
            array (
  0 => 'rental_id',
  1 => 'rental_date',
  2 => 'inventory_id',
  3 => 'customer_id',
  4 => 'return_date',
  5 => 'staff_id',
  6 => 'last_update',
),
            'rental_id',
            $limit
        );
    }
    /** @return array<string,array<string,mixed>> */
    public function loadHasMany(int|string $parentId): array
    {
        $result = [];
        $result['payment__customer_id'] = $this->getPaymentByCustomerId($parentId, 20);

        $result['rental__customer_id'] = $this->getRentalByCustomerId($parentId, 20);
        return $result;
    }
}
