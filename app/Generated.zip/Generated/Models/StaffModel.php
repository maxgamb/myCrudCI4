<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\StaffEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;
use RuntimeException;
use Throwable;


/**
 * Model for `staff`. Centralizes CRUD queries, filters, relations, and persistence.
 *
 * Convenzioni generate:
 * - no SQL query should be moved into the Controller;
 * - gli alias belongsTo leggibili sono esposti come <foreign_key>__label;
 * - hasMany e N:N dispongono di metodi dedicati facilmente personalizzabili;
 * - databaseManaged fields are not written by the application.
 */
final class StaffModel extends Model
{
    protected $table = 'staff';
    protected $primaryKey = 'staff_id';
    protected $returnType = StaffEntity::class;

    /** Schema whitelists used by cross-resource query reuse. */
    private const RESOURCE_FIELDS = array (
  0 => 'staff_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'address_id',
  4 => 'picture',
  5 => 'email',
  6 => 'store_id',
  7 => 'active',
  8 => 'username',
  9 => 'password',
  10 => 'last_update',
);
    private const RESOURCE_FIELD_TYPES = array (
  'staff_id' => 'tinyint',
  'first_name' => 'varchar',
  'last_name' => 'varchar',
  'address_id' => 'smallint',
  'picture' => 'blob',
  'email' => 'varchar',
  'store_id' => 'tinyint',
  'active' => 'tinyint',
  'username' => 'varchar',
  'password' => 'varchar',
  'last_update' => 'timestamp',
);
    private const FOREIGN_KEY_FIELDS = array (
  0 => 'address_id',
  1 => 'store_id',
);
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
  0 => 'first_name',
  1 => 'last_name',
  2 => 'address_id',
  3 => 'picture',
  4 => 'email',
  5 => 'store_id',
  6 => 'active',
  7 => 'username',
  8 => 'password',
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'staff_id' => 
  array (
    'type' => 'tinyint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'address_id' => 
  array (
    'type' => 'smallint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'store_id' => 
  array (
    'type' => 'tinyint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'staff_id',
  1 => 'address_id',
  2 => 'store_id',
);
    private const EXPORT_FIELDS = array (
  0 => 'staff_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'address_id',
  4 => 'email',
  5 => 'store_id',
  6 => 'active',
  7 => 'username',
  8 => 'password',
  9 => 'last_update',
);
    private const PRIMARY_KEYS = array (
  0 => 'staff_id',
);
    private const RELATION_SEARCHES = array (
  'address_id' => 
  array (
    'table' => 'address',
    'key' => 'address_id',
    'displayField' => 'address',
    'displayTemplate' => '',
    'displayFields' => 
    array (
      0 => 'address',
    ),
    'mode' => 'select',
  ),
  'store_id' => 
  array (
    'table' => 'store',
    'key' => 'store_id',
    'displayField' => 'store_id',
    'displayTemplate' => '',
    'displayFields' => 
    array (
      0 => 'store_id',
    ),
    'mode' => 'select',
  ),
);
    private const RELATED_CREATES = array (
  'store_id' => 
  array (
    'table' => 'store',
    'key' => 'store_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'manager_staff_id',
      1 => 'address_id',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
  ),
);
    private const RELATED_CREATE_RELATIONS = array (
  'store_id' => 
  array (
    'manager_staff_id' => 
    array (
      'table' => 'staff',
      'key' => 'staff_id',
      'displayField' => 'first_name',
      'mode' => 'select',
      'uniqueConsumerTable' => 'store',
      'uniqueConsumerField' => 'manager_staff_id',
    ),
    'address_id' => 
    array (
      'table' => 'address',
      'key' => 'address_id',
      'displayField' => 'address',
      'mode' => 'select',
      'uniqueConsumerTable' => '',
      'uniqueConsumerField' => '',
    ),
  ),
);
    private const MANY_TO_MANY = array (
);
    private const MANY_TO_MANY_RELATED_CREATES = array (
);
    private const COUNT_CACHE_SECONDS = 60;

    /**
     * Builds the full query used by detail and API.
     *
     * @return BaseBuilder Builder pronto per ulteriori condizioni.
     */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('staff');
        $builder->select([
            'staff.staff_id AS staff_id',
            'staff.first_name AS first_name',
            'staff.last_name AS last_name',
            'staff.address_id AS address_id',
            'staff.email AS email',
            'staff.store_id AS store_id',
            'staff.active AS active',
            'staff.username AS username',
            'staff.password AS password',
            'staff.last_update AS last_update',
            'address__address_id.address AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        return $builder;
    }

    /**
     * Builds the lightweight query used by the AJAX/paginated list.
     */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('staff');
        $builder->select([
            'staff.staff_id AS staff_id',
            'staff.first_name AS first_name',
            'staff.last_name AS last_name',
            'staff.address_id AS address_id',
            'staff.email AS email',
            'staff.store_id AS store_id',
            'staff.active AS active',
            'staff.username AS username',
            'staff.password AS password',
            'staff.last_update AS last_update',
            'address__address_id.address AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        return $builder;
    }

    /** Counts without JOINs so indexed filters remain inexpensive. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('staff');
        return $builder;
    }

    /** Returns the detail record with belongsTo labels already resolved. */
    public function getDetail(int|string $id): ?object
    {
        return $this->baseBuilder()
            ->where($this->table . '.' . $this->primaryKey, $id)
            ->get()
            ->getRow();
    }
    /**
     * Returns an HTML-ready page with the CI4 Pager.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows: array<int, object>, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'staff_id',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'staff_id';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('staff.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /**
     * Reads export records in chunks using the primary key as a stable cursor.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array<int, array<string, mixed>>
     */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('staff');
        $builder->select([
            'staff.staff_id AS staff_id',
            'staff.first_name AS first_name',
            'staff.last_name AS last_name',
            'staff.address_id AS address_id',
            'staff.email AS email',
            'staff.store_id AS store_id',
            'staff.active AS active',
            'staff.username AS username',
            'staff.password AS password',
            'staff.last_update AS last_update',
            'address__address_id.address AS address_id__label',
            'store__store_id.store_id AS store_id__label'
        ]);
        $this->joinAddressAddressId($builder);
        $this->joinStoreStoreId($builder);
        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('staff.staff_id >', $after);
        }

        return $builder
            ->orderBy('staff.staff_id', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /** Invalidates the list count cache after a write. */
    public function clearListCountCache(): void
    {
        service('cache')->delete('mycrud_list_total_' . md5($this->table));
    }
    /**
     * Applies the dynamic filter built by the site interface.
     * Field and operator are always checked against LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'staff.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Each condition is grouped so AND/OR behavior remains predictable even
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /**
     * Reusable option query for other generated resources.
     * All column names are checked against this Model's generated schema whitelist.
     *
     * @param list<string> $selectFields
     * @return list<array<string,mixed>>
     */
    public function relationOptionRows(
        string $key,
        array $selectFields,
        string $orderBy,
        string $query = '',
        ?string $id = null,
        int $limit = 500
    ): array {
        $allowed = array_fill_keys(self::RESOURCE_FIELDS, true);
        if (!isset($allowed[$key], $allowed[$orderBy])) {
            return [];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowed[$field])
        ));
        if ($selectFields === []) {
            $selectFields = [$key, $orderBy];
        }
        $builder = $this->db->table($this->table)
            ->select($selectFields)
            ->orderBy($orderBy, 'ASC')
            ->limit(max(1, min(5000, $limit)));
        if ($id !== null && $id !== '') {
            $builder->where($key, $id);
        } elseif (trim($query) !== '') {
            $builder->like($orderBy, trim($query), 'after');
        }
        return $builder->get()->getResultArray();
    }

    /**
     * Reusable child query. Only real FK fields of this resource may be used.
     *
     * @param list<string> $selectFields
     * @return array{rows:array<int,object>,count:int,hasMore:bool}
     */
    public function childrenByForeignKey(
        string $foreignKey,
        int|string $parentId,
        array $selectFields,
        string $orderBy,
        int $limit = 20
    ): array {
        $allowedFields = array_fill_keys(self::RESOURCE_FIELDS, true);
        $allowedForeignKeys = array_fill_keys(self::FOREIGN_KEY_FIELDS, true);
        if (!isset($allowedForeignKeys[$foreignKey], $allowedFields[$orderBy])) {
            return ['rows' => [], 'count' => 0, 'hasMore' => false];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowedFields[$field])
        ));
        if ($selectFields === []) {
            $selectFields = self::RESOURCE_FIELDS;
        }
        $selectExpressions = [];
        foreach ($selectFields as $field) {
            $type = strtolower((string) (self::RESOURCE_FIELD_TYPES[$field] ?? ''));
            if (in_array($type, ['point', 'geometry', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection'], true)) {
                $selectExpressions[] = 'ST_AsText(' . $this->db->protectIdentifiers($field) . ') AS ' . $this->db->protectIdentifiers($field);
            } else {
                $selectExpressions[] = $field;
            }
        }
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table($this->table)
            ->select($selectExpressions, false)
            ->where($foreignKey, $parentId)
            ->orderBy($orderBy, 'DESC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }
    /**
     * Inserts the current record and enabled atomic relations.
     *
     * @param array<string,mixed> $data
     * @param array<string,array<string,mixed>> $related
     * @param array<string,list<int|string>> $manyToMany
     * @param array<string,array<string,mixed>> $manyToManyNew
     * @return int|string
     * @throws RuntimeException|Throwable Se la persistenza non viene completata.
     */
    public function createRecord(
        array $data,
        array $related = [],
        array $manyToMany = [],
        array $manyToManyNew = []
    ): int|string {
        $this->db->transBegin();
        try {
            foreach ($related as $field => $payload) {
                if (!is_array($payload) || !isset(self::RELATED_CREATES[$field])) {
                    continue;
                }
                $data[$field] = $this->createRelatedRecord((string) $field, $payload);
            }
            $id = $this->insert($data, true);
            if ($id === false) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Inserimento non riuscito.');
            }

            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione di inserimento non riuscita.');
            }
            $this->db->transCommit();        } catch (Throwable $e) {
            $this->db->transRollback();            throw $e;
        }

        $this->clearListCountCache();
        return is_int($id) ? $id : (string) $id;
    }
    /**
     * Updates the current record.
     *
     * @param array<string,mixed> $data
     */
    public function updateRecordWithManyToMany(
        int|string $id,
        array $data,
        array $manyToMany = [],
        array $manyToManyNew = []
    ): bool {
        if ($manyToManyNew !== []) {
            throw new RuntimeException('Many-to-many related creation is not available for this CRUD.');
        }
        if (!$this->update($id, $data)) {
            return false;
        }

        $this->clearListCountCache();
        return true;
    }
    /**
     * Creates a single parent record authorized by generated configuration.
     *
     * @param array<string,mixed> $data
     * @return int|string
     * @throws RuntimeException
     */
    private function createRelatedRecord(string $field, array $data): int|string
    {
        $definition = self::RELATED_CREATES[$field] ?? null;
        if (!is_array($definition)) {
            throw new RuntimeException('Related-record creation is not authorized for ' . $field . '.');
        }

        $allowed = array_fill_keys((array) ($definition['fields'] ?? []), true);
        $payload = array_intersect_key($data, $allowed);
        $nullable = array_fill_keys((array) ($definition['nullableFields'] ?? []), true);
        $defaulted = array_fill_keys((array) ($definition['defaultedFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!is_string($payloadValue) || trim($payloadValue) !== '') {
                continue;
            }
            if (isset($defaulted[$payloadField])) {
                unset($payload[$payloadField]);
                continue;
            }
            if (isset($nullable[$payloadField])) {
                $payload[$payloadField] = null;
            }
        }

        foreach ((array) ($definition['dateTimeFields'] ?? []) as $dateTimeField) {
            if (isset($payload[$dateTimeField]) && is_string($payload[$dateTimeField])) {
                $payload[$dateTimeField] = str_replace('T', ' ', $payload[$dateTimeField]);
            }
        }

        $table = (string) ($definition['table'] ?? '');
        $key = (string) ($definition['key'] ?? '');
        if ($table === '' || $key === '') {
            throw new RuntimeException('Related-record configuration is incomplete.');
        }
        $builder = $this->db->table($table);
        $spatialFields = array_fill_keys((array) ($definition['spatialFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!isset($spatialFields[$payloadField])) {
                $builder->set($payloadField, $payloadValue);
                continue;
            }

            $wkt = trim((string) $payloadValue);
            if ($wkt === '') {
                throw new RuntimeException('Spatial value is required for ' . $payloadField . '.');
            }
            // WKT is escaped as a value; only the trusted SQL function is raw.
            $builder->set($payloadField, 'ST_GeomFromText(' . $this->db->escape($wkt) . ')', false);
        }
        if (!$builder->insert()) {
            $dbError = (array) $this->db->error();
            $dbCode = trim((string) ($dbError['code'] ?? ''));
            $dbMessage = trim((string) ($dbError['message'] ?? ''));
            $detail = $dbMessage !== ''
                ? ' Database error' . ($dbCode !== '' ? ' [' . $dbCode . ']' : '') . ': ' . $dbMessage
                : '';
            log_message('error', 'Related Create insert failed for {table}: {code} {message}', [
                'table' => $table,
                'code' => $dbCode,
                'message' => $dbMessage,
            ]);
            throw new RuntimeException('Unable to insert related record: ' . $table . '.' . $detail);
        }

        if (!empty($definition['keyAutoIncrement'])) {
            $id = $this->db->insertID();
            if ($id === 0 || $id === '0' || $id === '') {
                throw new RuntimeException('Generated key is not available for ' . $table . '.');
            }
            return is_int($id) ? $id : (string) $id;
        }

        $id = $payload[$key] ?? null;
        if (!is_int($id) && !is_string($id)) {
            throw new RuntimeException('The related-record key must have a value: ' . $key . '.');
        }

        return $id;
    }
    /** FK staff.address_id -> address.address_id; risultato: address_id__label. */
    private function joinAddressAddressId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'address AS address__address_id',
            'address__address_id.address_id = staff.address_id',
            'left'
        );

        return $builder;
    }
    /** FK staff.store_id -> store.store_id; risultato: store_id__label. */
    private function joinStoreStoreId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'store AS store__store_id',
            'store__store_id.store_id = staff.store_id',
            'left'
        );

        return $builder;
    }
    /** Paginated REST list with filter and sorting whitelists. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('staff.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'staff_id');
        $sort = in_array($sort, $sortable, true) ? $sort : 'staff_id';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('staff.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
    /** Returns options for the address_id relation through the owning parent Model. */
    public function getAddressAddressIdOptions(): array
    {
        return (new \App\Models\AddressModel())->relationOptionRows(
            'address_id',
            array (
  0 => 'address_id',
  1 => 'address',
),
            'address'
        );
    }
    /** Returns options for the store_id relation through the owning parent Model. */
    public function getStoreStoreIdOptions(): array
    {
        return (new \App\Models\StoreModel())->relationOptionRows(
            'store_id',
            array (
  0 => 'store_id',
),
            'store_id'
        );
    }
    /**
     * Options for foreign keys belonging to inline-created parents.
     * La whitelist deriva esclusivamente dalle FK reali dello schema.
     *
     * @return array<string,array<string,list<array{id:string,text:string}>>>
     */
    public function relatedCreateRelationOptions(): array
    {
        $result = [];
        foreach (self::RELATED_CREATE_RELATIONS as $relationField => $fields) {
            foreach ((array) $fields as $field => $definition) {
                if (($definition['mode'] ?? 'select') !== 'select') {
                    continue;
                }
                $table = (string) $definition['table'];
                $key = (string) $definition['key'];
                $display = (string) $definition['displayField'];
                $builder = $this->db->table($table)
                    ->select([$key, $display])
                    ->orderBy($display, 'ASC');

                // If this FK is UNIQUE in the inline-created table, choices
                // already referenced there would necessarily fail validation
                // (and the database constraint). Hide them before rendering
                // the Related Create select instead of asking the user to
                // discover the conflict after submit.
                $consumerTable = trim((string) ($definition['uniqueConsumerTable'] ?? ''));
                $consumerField = trim((string) ($definition['uniqueConsumerField'] ?? ''));
                if ($consumerTable !== '' && $consumerField !== '') {
                    $usedRows = $this->db->table($consumerTable)
                        ->select($consumerField)
                        ->where($consumerField . ' IS NOT NULL', null, false)
                        ->get()
                        ->getResultArray();
                    $usedIds = array_values(array_unique(array_filter(
                        array_map(
                            static fn (array $row): string => (string) ($row[$consumerField] ?? ''),
                            $usedRows
                        ),
                        static fn (string $value): bool => $value !== ''
                    )));
                    if ($usedIds !== []) {
                        $builder->whereNotIn($key, $usedIds);
                    }
                }

                $rows = $builder->get()->getResultArray();
                foreach ($rows as $row) {
                    $result[(string) $relationField][(string) $field][] = [
                        'id' => (string) ($row[$key] ?? ''),
                        'text' => (string) ($row[$display] ?? $row[$key] ?? ''),
                    ];
                }
            }
        }
        return $result;
    }
    /** @return array<string,array<string,string>> */
    public function relationOptions(): array
    {
        return [
            'address_id' => $this->toRelationOptions($this->getAddressAddressIdOptions(), 'address_id'),
            'store_id' => $this->toRelationOptions($this->getStoreStoreIdOptions(), 'store_id'),
        ];
    }

    /**
     * Server-side option search for large relations.
     * Table, key, and descriptive fields come only from the generated whitelist.
     *
     * @return list<array{id:string,text:string}>
     */
    public function searchRelationOptions(string $field, string $query, int $limit = 20): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $limit = max(1, min(100, $limit));
        $builder = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->orderBy((string) $definition['displayField'], 'ASC')
            ->limit($limit);

        $query = trim($query);
        if ($query !== '' && $displayFields !== []) {
            $builder->groupStart();
            foreach ($displayFields as $index => $displayColumn) {
                if ($index === 0) {
                    $builder->like((string) $displayColumn, $query, 'after');
                } else {
                    $builder->orLike((string) $displayColumn, $query, 'after');
                }
            }
            $builder->groupEnd();
        }

        $rows = $builder->get()->getResultArray();
        $result = [];
        foreach ($rows as $row) {
            $result[] = [
                'id' => (string) ($row[$key] ?? ''),
                'text' => $this->formatRelationLabel($row, $definition),
            ];
        }

        return $result;
    }

    /** @return array{id:string,text:string}|null */
    public function relationOptionById(string $field, int|string $id): ?array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return null;
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $row = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->where($key, $id)
            ->limit(1)
            ->get()
            ->getRowArray();

        if (!is_array($row)) {
            return null;
        }

        return [
            'id' => (string) ($row[$key] ?? ''),
            'text' => $this->formatRelationLabel($row, $definition),
        ];
    }

    /** @return array<string,string> */
    private function toRelationOptions(array $rows, string $field): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $options = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $options[(string) ($row[$key] ?? '')] = $this->formatRelationLabel($row, $definition);
        }
        return $options;
    }

    private function formatRelationLabel(array $row, array $definition): string
    {
        $template = trim((string) ($definition['displayTemplate'] ?? ''));
        if ($template === '') {
            return trim((string) ($row[(string) $definition['displayField']] ?? ''));
        }

        $label = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/',
            static fn (array $match): string => (string) ($row[$match[1]] ?? ''),
            $template
        );

        return trim((string) $label);
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table payment.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getPaymentByStaffId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\PaymentModel())->childrenByForeignKey(
            'staff_id',
            $parentId,
            array (
  0 => 'payment_id',
  1 => 'customer_id',
  2 => 'staff_id',
  3 => 'rental_id',
  4 => 'amount',
  5 => 'payment_date',
  6 => 'last_update',
),
            'payment_id',
            $limit
        );
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table rental.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getRentalByStaffId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\RentalModel())->childrenByForeignKey(
            'staff_id',
            $parentId,
            array (
  0 => 'rental_id',
  1 => 'rental_date',
  2 => 'inventory_id',
  3 => 'customer_id',
  4 => 'return_date',
  5 => 'staff_id',
  6 => 'last_update',
),
            'rental_id',
            $limit
        );
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table store.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getStoreByManagerStaffId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\StoreModel())->childrenByForeignKey(
            'manager_staff_id',
            $parentId,
            array (
  0 => 'store_id',
  1 => 'manager_staff_id',
  2 => 'address_id',
  3 => 'last_update',
),
            'store_id',
            $limit
        );
    }
    /** @return array<string,array<string,mixed>> */
    public function loadHasMany(int|string $parentId): array
    {
        $result = [];
        $result['payment__staff_id'] = $this->getPaymentByStaffId($parentId, 20);

        $result['rental__staff_id'] = $this->getRentalByStaffId($parentId, 20);

        $result['store__manager_staff_id'] = $this->getStoreByManagerStaffId($parentId, 20);
        return $result;
    }
}
