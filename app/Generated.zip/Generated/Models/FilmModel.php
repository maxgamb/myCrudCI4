<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\FilmEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;
use RuntimeException;
use Throwable;


/**
 * Model for `film`. Centralizes CRUD queries, filters, relations, and persistence.
 *
 * Convenzioni generate:
 * - no SQL query should be moved into the Controller;
 * - gli alias belongsTo leggibili sono esposti come <foreign_key>__label;
 * - hasMany e N:N dispongono di metodi dedicati facilmente personalizzabili;
 * - databaseManaged fields are not written by the application.
 */
final class FilmModel extends Model
{
    protected $table = 'film';
    protected $primaryKey = 'film_id';
    protected $returnType = FilmEntity::class;

    /** Schema whitelists used by cross-resource query reuse. */
    private const RESOURCE_FIELDS = array (
  0 => 'film_id',
  1 => 'title',
  2 => 'description',
  3 => 'release_year',
  4 => 'language_id',
  5 => 'original_language_id',
  6 => 'rental_duration',
  7 => 'rental_rate',
  8 => 'length',
  9 => 'replacement_cost',
  10 => 'rating',
  11 => 'special_features',
  12 => 'last_update',
  13 => 'uploads',
);
    private const RESOURCE_FIELD_TYPES = array (
  'film_id' => 'smallint',
  'title' => 'varchar',
  'description' => 'text',
  'release_year' => 'year',
  'language_id' => 'tinyint',
  'original_language_id' => 'tinyint',
  'rental_duration' => 'tinyint',
  'rental_rate' => 'decimal',
  'length' => 'smallint',
  'replacement_cost' => 'decimal',
  'rating' => 'enum',
  'special_features' => 'set',
  'last_update' => 'timestamp',
  'uploads' => 'varchar',
);
    private const FOREIGN_KEY_FIELDS = array (
  0 => 'language_id',
  1 => 'original_language_id',
);
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
  0 => 'title',
  1 => 'description',
  2 => 'release_year',
  3 => 'language_id',
  4 => 'original_language_id',
  5 => 'rental_duration',
  6 => 'rental_rate',
  7 => 'length',
  8 => 'replacement_cost',
  9 => 'rating',
  10 => 'special_features',
  11 => 'uploads',
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'film_id' => 
  array (
    'type' => 'smallint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'title' => 
  array (
    'type' => 'varchar',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'starts_with',
      3 => 'contains',
      4 => 'ends_with',
      5 => 'is_null',
      6 => 'not_null',
    ),
  ),
  'language_id' => 
  array (
    'type' => 'tinyint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'original_language_id' => 
  array (
    'type' => 'tinyint',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'film_id',
  1 => 'title',
  2 => 'language_id',
  3 => 'original_language_id',
);
    private const EXPORT_FIELDS = array (
  0 => 'film_id',
  1 => 'title',
  2 => 'description',
  3 => 'release_year',
  4 => 'language_id',
  5 => 'original_language_id',
  6 => 'rental_duration',
  7 => 'rental_rate',
  8 => 'length',
  9 => 'replacement_cost',
  10 => 'rating',
  11 => 'special_features',
  12 => 'last_update',
);
    private const PRIMARY_KEYS = array (
  0 => 'film_id',
);
    private const RELATION_SEARCHES = array (
  'language_id' => 
  array (
    'table' => 'language',
    'key' => 'language_id',
    'displayField' => 'name',
    'displayTemplate' => '',
    'displayFields' => 
    array (
      0 => 'name',
    ),
    'mode' => 'select',
  ),
  'original_language_id' => 
  array (
    'table' => 'language',
    'key' => 'language_id',
    'displayField' => 'name',
    'displayTemplate' => '',
    'displayFields' => 
    array (
      0 => 'name',
    ),
    'mode' => 'select',
  ),
);
    private const RELATED_CREATES = array (
  'language_id' => 
  array (
    'table' => 'language',
    'key' => 'language_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'name',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
  ),
  'original_language_id' => 
  array (
    'table' => 'language',
    'key' => 'language_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'name',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
  ),
);
    private const RELATED_CREATE_RELATIONS = array (
);
    private const MANY_TO_MANY = array (
  'many__film_actor__film_id' => 
  array (
    'pivotTable' => 'film_actor',
    'ownPivotField' => 'film_id',
    'relatedTable' => 'actor',
    'relatedPivotField' => 'actor_id',
    'relatedKey' => 'actor_id',
    'displayField' => 'first_name',
    'displayFields' => 
    array (
      0 => 'first_name',
      1 => 'last_name',
    ),
    'createEnabled' => true,
    'editEnabled' => true,
    'createRelatedEnabled' => true,
  ),
  'many__film_category__film_id' => 
  array (
    'pivotTable' => 'film_category',
    'ownPivotField' => 'film_id',
    'relatedTable' => 'category',
    'relatedPivotField' => 'category_id',
    'relatedKey' => 'category_id',
    'displayField' => 'name',
    'displayFields' => 
    array (
      0 => 'name',
    ),
    'createEnabled' => true,
    'editEnabled' => true,
    'createRelatedEnabled' => true,
  ),
);
    private const MANY_TO_MANY_RELATED_CREATES = array (
  'many__film_actor__film_id' => 
  array (
    'table' => 'actor',
    'key' => 'actor_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'first_name',
      1 => 'last_name',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
    'relations' => 
    array (
    ),
  ),
  'many__film_category__film_id' => 
  array (
    'table' => 'category',
    'key' => 'category_id',
    'keyAutoIncrement' => true,
    'fields' => 
    array (
      0 => 'name',
    ),
    'nullableFields' => 
    array (
    ),
    'defaultedFields' => 
    array (
    ),
    'dateTimeFields' => 
    array (
    ),
    'spatialFields' => 
    array (
    ),
    'relations' => 
    array (
    ),
  ),
);
    private const COUNT_CACHE_SECONDS = 60;

    /**
     * Builds the full query used by detail and API.
     *
     * @return BaseBuilder Builder pronto per ulteriori condizioni.
     */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('film');
        $builder->select([
            'film.film_id AS film_id',
            'film.title AS title',
            'film.description AS description',
            'film.release_year AS release_year',
            'film.language_id AS language_id',
            'film.original_language_id AS original_language_id',
            'film.rental_duration AS rental_duration',
            'film.rental_rate AS rental_rate',
            'film.length AS length',
            'film.replacement_cost AS replacement_cost',
            'film.rating AS rating',
            'film.special_features AS special_features',
            'film.last_update AS last_update',
            'film.uploads AS uploads',
            'language__language_id.name AS language_id__label',
            'language__original_language_id.name AS original_language_id__label'
        ]);
        $this->joinLanguageLanguageId($builder);
        $this->joinLanguageOriginalLanguageId($builder);
        return $builder;
    }

    /**
     * Builds the lightweight query used by the AJAX/paginated list.
     */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('film');
        $builder->select([
            'film.film_id AS film_id',
            'film.title AS title',
            'film.description AS description',
            'film.release_year AS release_year',
            'film.language_id AS language_id',
            'film.original_language_id AS original_language_id',
            'film.rental_duration AS rental_duration',
            'film.rental_rate AS rental_rate',
            'film.length AS length',
            'film.replacement_cost AS replacement_cost',
            'film.rating AS rating',
            'film.special_features AS special_features',
            'film.last_update AS last_update',
            'language__language_id.name AS language_id__label',
            'language__original_language_id.name AS original_language_id__label'
        ]);
        $this->joinLanguageLanguageId($builder);
        $this->joinLanguageOriginalLanguageId($builder);
        return $builder;
    }

    /** Counts without JOINs so indexed filters remain inexpensive. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('film');
        return $builder;
    }

    /** Returns the detail record with belongsTo labels already resolved. */
    public function getDetail(int|string $id): ?object
    {
        return $this->baseBuilder()
            ->where($this->table . '.' . $this->primaryKey, $id)
            ->get()
            ->getRow();
    }
    /**
     * Returns an HTML-ready page with the CI4 Pager.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows: array<int, object>, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'film_id',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'film_id';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('film.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /**
     * Reads export records in chunks using the primary key as a stable cursor.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array<int, array<string, mixed>>
     */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('film');
        $builder->select([
            'film.film_id AS film_id',
            'film.title AS title',
            'film.description AS description',
            'film.release_year AS release_year',
            'film.language_id AS language_id',
            'film.original_language_id AS original_language_id',
            'film.rental_duration AS rental_duration',
            'film.rental_rate AS rental_rate',
            'film.length AS length',
            'film.replacement_cost AS replacement_cost',
            'film.rating AS rating',
            'film.special_features AS special_features',
            'film.last_update AS last_update',
            'language__language_id.name AS language_id__label',
            'language__original_language_id.name AS original_language_id__label'
        ]);
        $this->joinLanguageLanguageId($builder);
        $this->joinLanguageOriginalLanguageId($builder);
        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('film.film_id >', $after);
        }

        return $builder
            ->orderBy('film.film_id', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    /** Invalidates the list count cache after a write. */
    public function clearListCountCache(): void
    {
        service('cache')->delete('mycrud_list_total_' . md5($this->table));
    }
    /**
     * Applies the dynamic filter built by the site interface.
     * Field and operator are always checked against LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'film.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Each condition is grouped so AND/OR behavior remains predictable even
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /**
     * Reusable option query for other generated resources.
     * All column names are checked against this Model's generated schema whitelist.
     *
     * @param list<string> $selectFields
     * @return list<array<string,mixed>>
     */
    public function relationOptionRows(
        string $key,
        array $selectFields,
        string $orderBy,
        string $query = '',
        ?string $id = null,
        int $limit = 500
    ): array {
        $allowed = array_fill_keys(self::RESOURCE_FIELDS, true);
        if (!isset($allowed[$key], $allowed[$orderBy])) {
            return [];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowed[$field])
        ));
        if ($selectFields === []) {
            $selectFields = [$key, $orderBy];
        }
        $builder = $this->db->table($this->table)
            ->select($selectFields)
            ->orderBy($orderBy, 'ASC')
            ->limit(max(1, min(5000, $limit)));
        if ($id !== null && $id !== '') {
            $builder->where($key, $id);
        } elseif (trim($query) !== '') {
            $builder->like($orderBy, trim($query), 'after');
        }
        return $builder->get()->getResultArray();
    }

    /**
     * Reusable child query. Only real FK fields of this resource may be used.
     *
     * @param list<string> $selectFields
     * @return array{rows:array<int,object>,count:int,hasMore:bool}
     */
    public function childrenByForeignKey(
        string $foreignKey,
        int|string $parentId,
        array $selectFields,
        string $orderBy,
        int $limit = 20
    ): array {
        $allowedFields = array_fill_keys(self::RESOURCE_FIELDS, true);
        $allowedForeignKeys = array_fill_keys(self::FOREIGN_KEY_FIELDS, true);
        if (!isset($allowedForeignKeys[$foreignKey], $allowedFields[$orderBy])) {
            return ['rows' => [], 'count' => 0, 'hasMore' => false];
        }
        $selectFields = array_values(array_filter(
            array_unique(array_map('strval', $selectFields)),
            static fn (string $field): bool => isset($allowedFields[$field])
        ));
        if ($selectFields === []) {
            $selectFields = self::RESOURCE_FIELDS;
        }
        $selectExpressions = [];
        foreach ($selectFields as $field) {
            $type = strtolower((string) (self::RESOURCE_FIELD_TYPES[$field] ?? ''));
            if (in_array($type, ['point', 'geometry', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection'], true)) {
                $selectExpressions[] = 'ST_AsText(' . $this->db->protectIdentifiers($field) . ') AS ' . $this->db->protectIdentifiers($field);
            } else {
                $selectExpressions[] = $field;
            }
        }
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table($this->table)
            ->select($selectExpressions, false)
            ->where($foreignKey, $parentId)
            ->orderBy($orderBy, 'DESC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }
    /**
     * Inserts the current record and enabled atomic relations.
     *
     * @param array<string,mixed> $data
     * @param array<string,array<string,mixed>> $related
     * @param array<string,list<int|string>> $manyToMany
     * @param array<string,array<string,mixed>> $manyToManyNew
     * @return int|string
     * @throws RuntimeException|Throwable Se la persistenza non viene completata.
     */
    public function createRecord(
        array $data,
        array $related = [],
        array $manyToMany = [],
        array $manyToManyNew = []
    ): int|string {
        $this->db->transBegin();
        try {
            foreach ($related as $field => $payload) {
                if (!is_array($payload) || !isset(self::RELATED_CREATES[$field])) {
                    continue;
                }
                $data[$field] = $this->createRelatedRecord((string) $field, $payload);
            }
            if ($manyToManyNew !== []) {
                $this->createManyToManyRelatedRecords($manyToManyNew, $manyToMany);
            }
            $id = $this->insert($data, true);
            if ($id === false) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Inserimento non riuscito.');
            }

            if ($manyToMany !== []) {
                $this->applyManyToMany((string) $id, $manyToMany, 'createEnabled');
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione di inserimento non riuscita.');
            }
            $this->db->transCommit();        } catch (Throwable $e) {
            $this->db->transRollback();            throw $e;
        }

        $this->clearListCountCache();
        return is_int($id) ? $id : (string) $id;
    }
    /**
     * Returns available options for form many-to-many selectors.
     *
     * @return array<string,list<array{id:string,text:string}>>
     */
    public function manyToManyFormOptions(): array
    {
        $result = [];
        foreach (self::MANY_TO_MANY as $key => $definition) {
            $table = (string) ($definition['relatedTable'] ?? '');
            $id = (string) ($definition['relatedKey'] ?? '');
            $label = (string) ($definition['displayField'] ?? $id);
            $labelFields = array_values(array_filter(array_map('strval', (array) ($definition['displayFields'] ?? []))));
            if ($labelFields === []) {
                $labelFields = [$label];
            }
            if ($table === '' || $id === '' || $label === '') {
                continue;
            }
            $selectFields = array_values(array_unique(array_merge([$id], $labelFields)));
            $rows = $this->db->table($table)
                ->select($selectFields)
                ->orderBy($labelFields[0], 'ASC')
                ->limit(500)
                ->get()
                ->getResultArray();
            $result[$key] = array_map(static function (array $row) use ($id, $labelFields): array {
                $parts = [];
                foreach ($labelFields as $field) {
                    $value = trim((string) ($row[$field] ?? ''));
                    if ($value !== '') {
                        $parts[] = $value;
                    }
                }
                return [
                    'id' => (string) ($row[$id] ?? ''),
                    'text' => $parts !== [] ? implode(' ', $parts) : (string) ($row[$id] ?? ''),
                ];
            }, $rows);
        }
        return $result;
    }
    /**
     * Options for foreign keys inside inline-created many-to-many targets.
     *
     * @return array<string,array<string,list<array{id:string,text:string}>>>
     */
    public function manyToManyRelatedCreateRelationOptions(): array
    {
        $result = [];

        foreach (self::MANY_TO_MANY_RELATED_CREATES as $relationKey => $definition) {
            foreach ((array) ($definition['relations'] ?? []) as $field => $relation) {
                if (($relation['mode'] ?? 'select') !== 'select') {
                    continue;
                }

                $table = (string) ($relation['table'] ?? '');
                $key = (string) ($relation['key'] ?? '');
                $display = (string) ($relation['displayField'] ?? '');
                if ($table === '' || $key === '' || $display === '') {
                    continue;
                }

                $rows = $this->db->table($table)
                    ->select([$key, $display])
                    ->orderBy($display, 'ASC')
                    ->limit(5000)
                    ->get()
                    ->getResultArray();

                foreach ($rows as $row) {
                    $result[(string) $relationKey][(string) $field][] = [
                        'id' => (string) ($row[$key] ?? ''),
                        'text' => (string) ($row[$display] ?? $row[$key] ?? ''),
                    ];
                }
            }
        }

        return $result;
    }
    /**
     * Returns IDs already associated with the record for each many-to-many relation.
     *
     * @return array<string,list<string>>
     */
    public function manyToManySelected(int|string $parentId): array
    {
        $result = [];
        foreach (self::MANY_TO_MANY as $key => $definition) {
            $pivot = (string) ($definition['pivotTable'] ?? '');
            $own = (string) ($definition['ownPivotField'] ?? '');
            $related = (string) ($definition['relatedPivotField'] ?? '');
            if ($pivot === '' || $own === '' || $related === '') {
                continue;
            }
            $rows = $this->db->table($pivot)
                ->select($related)
                ->where($own, $parentId)
                ->get()
                ->getResultArray();
            $result[$key] = array_map('strval', array_column($rows, $related));
        }
        return $result;
    }
    /**
     * Updates the record and synchronizes pure pivots in a single transaction.
     *
     * @param array<string,mixed> $data
     * @param array<string,list<int|string>> $manyToMany
     * @throws RuntimeException|Throwable
     */
    public function updateRecordWithManyToMany(
        int|string $id,
        array $data,
        array $manyToMany = [],
        array $manyToManyNew = []
    ): bool {
        $this->db->transBegin();
        try {
            if ($manyToManyNew !== []) {
                $this->createManyToManyRelatedRecords($manyToManyNew, $manyToMany);
            }
            if (!$this->update($id, $data)) {
                throw new RuntimeException(implode(' ', $this->errors()) ?: 'Update failed.');
            }
            if ($manyToMany !== []) {
                $this->applyManyToMany((string) $id, $manyToMany, 'editEnabled');
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Transazione N:N non riuscita.');
            }
            $this->db->transCommit();
            $this->clearListCountCache();
            return true;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }
    /**
     * Valida gli ID target e sincronizza esclusivamente le righe pivot autorizzate.
     * Does not update or delete records from the target table.
     *
     * @param array<string,list<int|string>> $payload
     * @throws RuntimeException
     */
    private function applyManyToMany(int|string $parentId, array $payload, string $permission): void
    {
        foreach ($payload as $key => $ids) {
            $definition = self::MANY_TO_MANY[$key] ?? null;
            if (!is_array($definition) || empty($definition[$permission])) {
                continue;
            }
            $ids = is_array($ids) ? $ids : [];
            $ids = array_values(array_unique(array_map('strval', array_filter(
                $ids,
                static fn ($id): bool => is_scalar($id) && trim((string) $id) !== ''
            ))));
            if (count($ids) > 500) {
                throw new RuntimeException('Troppe associazioni N:N per ' . $key . '.');
            }

            $relatedTable = (string) ($definition['relatedTable'] ?? '');
            $relatedKey = (string) ($definition['relatedKey'] ?? '');
            if ($ids !== []) {
                $validRows = $this->db->table($relatedTable)
                    ->select($relatedKey)
                    ->whereIn($relatedKey, $ids)
                    ->get()
                    ->getResultArray();
                $valid = array_map('strval', array_column($validRows, $relatedKey));
                if (count(array_unique($valid)) !== count($ids)) {
                    throw new RuntimeException('One or more many-to-many records do not exist for ' . $key . '.');
                }
            }

            $pivot = (string) ($definition['pivotTable'] ?? '');
            $own = (string) ($definition['ownPivotField'] ?? '');
            $related = (string) ($definition['relatedPivotField'] ?? '');
            $existingRows = $this->db->table($pivot)
                ->select($related)
                ->where($own, $parentId)
                ->get()
                ->getResultArray();
            $existing = array_map('strval', array_column($existingRows, $related));
            foreach (array_diff($ids, $existing) as $attachId) {
                if (!$this->db->table($pivot)->insert([$own => $parentId, $related => $attachId])) {
                    throw new RuntimeException('Attach pivot non riuscito.');
                }
            }
            $detach = array_values(array_diff($existing, $ids));
            if ($detach !== []) {
                $this->db->table($pivot)->where($own, $parentId)->whereIn($related, $detach)->delete();
            }
        }
    }
    /**
     * Creates configured many-to-many target records and appends their IDs
     * to the association payload. The caller owns the surrounding transaction.
     *
     * @param array<string,array<string,mixed>> $newRecords
     * @param array<string,list<int|string>> $manyToMany
     */
    private function createManyToManyRelatedRecords(array $newRecords, array &$manyToMany): void
    {
        foreach ($newRecords as $relationKey => $data) {
            if (!is_array($data) || !isset(self::MANY_TO_MANY_RELATED_CREATES[$relationKey])) {
                continue;
            }

            $definition = self::MANY_TO_MANY_RELATED_CREATES[$relationKey];
            $allowed = array_fill_keys((array) ($definition['fields'] ?? []), true);
            $payload = array_intersect_key($data, $allowed);
            $nullable = array_fill_keys((array) ($definition['nullableFields'] ?? []), true);
            $defaulted = array_fill_keys((array) ($definition['defaultedFields'] ?? []), true);

            foreach ($payload as $field => $value) {
                if (!is_string($value) || trim($value) !== '') {
                    continue;
                }
                if (isset($defaulted[$field])) {
                    unset($payload[$field]);
                    continue;
                }
                if (isset($nullable[$field])) {
                    $payload[$field] = null;
                }
            }

            foreach ((array) ($definition['dateTimeFields'] ?? []) as $dateTimeField) {
                if (isset($payload[$dateTimeField]) && is_string($payload[$dateTimeField])) {
                    $payload[$dateTimeField] = str_replace('T', ' ', $payload[$dateTimeField]);
                }
            }

            $table = (string) ($definition['table'] ?? '');
            $key = (string) ($definition['key'] ?? '');
            if ($table === '' || $key === '') {
                throw new RuntimeException('Many-to-many related-create configuration is incomplete.');
            }

            foreach ((array) ($definition['relations'] ?? []) as $field => $relation) {
                if (!array_key_exists($field, $payload)) {
                    continue;
                }

                $value = $payload[$field];
                if ($value === null || (is_scalar($value) && trim((string) $value) === '')) {
                    continue;
                }

                $parentTable = (string) ($relation['table'] ?? '');
                $parentKey = (string) ($relation['key'] ?? '');
                if ($parentTable === '' || $parentKey === '') {
                    throw new RuntimeException('Nested relation configuration is incomplete for ' . $field . '.');
                }

                $exists = $this->db->table($parentTable)
                    ->select($parentKey)
                    ->where($parentKey, $value)
                    ->limit(1)
                    ->get()
                    ->getRowArray();

                if (!is_array($exists)) {
                    throw new RuntimeException('Invalid related value for ' . $field . '.');
                }
            }

            if (!$this->db->table($table)->insert($payload)) {
                throw new RuntimeException('Unable to create many-to-many related record: ' . $table . '.');
            }

            if (!empty($definition['keyAutoIncrement'])) {
                $newId = $this->db->insertID();
            } else {
                $newId = $payload[$key] ?? null;
            }

            if (!is_int($newId) && !is_string($newId)) {
                throw new RuntimeException('Created related record key is unavailable for ' . $table . '.');
            }
            if ((string) $newId === '' || (string) $newId === '0') {
                throw new RuntimeException('Created related record key is invalid for ' . $table . '.');
            }

            $manyToMany[(string) $relationKey] ??= [];
            $manyToMany[(string) $relationKey][] = $newId;
            $manyToMany[(string) $relationKey] = array_values(array_unique(
                array_map('strval', $manyToMany[(string) $relationKey])
            ));
        }
    }
    /**
     * Creates a single parent record authorized by generated configuration.
     *
     * @param array<string,mixed> $data
     * @return int|string
     * @throws RuntimeException
     */
    private function createRelatedRecord(string $field, array $data): int|string
    {
        $definition = self::RELATED_CREATES[$field] ?? null;
        if (!is_array($definition)) {
            throw new RuntimeException('Related-record creation is not authorized for ' . $field . '.');
        }

        $allowed = array_fill_keys((array) ($definition['fields'] ?? []), true);
        $payload = array_intersect_key($data, $allowed);
        $nullable = array_fill_keys((array) ($definition['nullableFields'] ?? []), true);
        $defaulted = array_fill_keys((array) ($definition['defaultedFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!is_string($payloadValue) || trim($payloadValue) !== '') {
                continue;
            }
            if (isset($defaulted[$payloadField])) {
                unset($payload[$payloadField]);
                continue;
            }
            if (isset($nullable[$payloadField])) {
                $payload[$payloadField] = null;
            }
        }

        foreach ((array) ($definition['dateTimeFields'] ?? []) as $dateTimeField) {
            if (isset($payload[$dateTimeField]) && is_string($payload[$dateTimeField])) {
                $payload[$dateTimeField] = str_replace('T', ' ', $payload[$dateTimeField]);
            }
        }

        $table = (string) ($definition['table'] ?? '');
        $key = (string) ($definition['key'] ?? '');
        if ($table === '' || $key === '') {
            throw new RuntimeException('Related-record configuration is incomplete.');
        }
        $builder = $this->db->table($table);
        $spatialFields = array_fill_keys((array) ($definition['spatialFields'] ?? []), true);
        foreach ($payload as $payloadField => $payloadValue) {
            if (!isset($spatialFields[$payloadField])) {
                $builder->set($payloadField, $payloadValue);
                continue;
            }

            $wkt = trim((string) $payloadValue);
            if ($wkt === '') {
                throw new RuntimeException('Spatial value is required for ' . $payloadField . '.');
            }
            // WKT is escaped as a value; only the trusted SQL function is raw.
            $builder->set($payloadField, 'ST_GeomFromText(' . $this->db->escape($wkt) . ')', false);
        }
        if (!$builder->insert()) {
            $dbError = (array) $this->db->error();
            $dbCode = trim((string) ($dbError['code'] ?? ''));
            $dbMessage = trim((string) ($dbError['message'] ?? ''));
            $detail = $dbMessage !== ''
                ? ' Database error' . ($dbCode !== '' ? ' [' . $dbCode . ']' : '') . ': ' . $dbMessage
                : '';
            log_message('error', 'Related Create insert failed for {table}: {code} {message}', [
                'table' => $table,
                'code' => $dbCode,
                'message' => $dbMessage,
            ]);
            throw new RuntimeException('Unable to insert related record: ' . $table . '.' . $detail);
        }

        if (!empty($definition['keyAutoIncrement'])) {
            $id = $this->db->insertID();
            if ($id === 0 || $id === '0' || $id === '') {
                throw new RuntimeException('Generated key is not available for ' . $table . '.');
            }
            return is_int($id) ? $id : (string) $id;
        }

        $id = $payload[$key] ?? null;
        if (!is_int($id) && !is_string($id)) {
            throw new RuntimeException('The related-record key must have a value: ' . $key . '.');
        }

        return $id;
    }
    /** FK film.language_id -> language.language_id; risultato: language_id__label. */
    private function joinLanguageLanguageId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'language AS language__language_id',
            'language__language_id.language_id = film.language_id',
            'left'
        );

        return $builder;
    }
    /** FK film.original_language_id -> language.language_id; risultato: original_language_id__label. */
    private function joinLanguageOriginalLanguageId(BaseBuilder $builder): BaseBuilder
    {
        $builder->join(
            'language AS language__original_language_id',
            'language__original_language_id.language_id = film.original_language_id',
            'left'
        );

        return $builder;
    }
    /** Paginated REST list with filter and sorting whitelists. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('film.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'film_id');
        $sort = in_array($sort, $sortable, true) ? $sort : 'film_id';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('film.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
    /** Returns options for the language_id relation through the owning parent Model. */
    public function getLanguageLanguageIdOptions(): array
    {
        return (new \App\Models\LanguageModel())->relationOptionRows(
            'language_id',
            array (
  0 => 'language_id',
  1 => 'name',
),
            'name'
        );
    }
    /** Returns options for the original_language_id relation through the owning parent Model. */
    public function getLanguageOriginalLanguageIdOptions(): array
    {
        return (new \App\Models\LanguageModel())->relationOptionRows(
            'language_id',
            array (
  0 => 'language_id',
  1 => 'name',
),
            'name'
        );
    }
    /**
     * Options for foreign keys belonging to inline-created parents.
     * La whitelist deriva esclusivamente dalle FK reali dello schema.
     *
     * @return array<string,array<string,list<array{id:string,text:string}>>>
     */
    public function relatedCreateRelationOptions(): array
    {
        $result = [];
        foreach (self::RELATED_CREATE_RELATIONS as $relationField => $fields) {
            foreach ((array) $fields as $field => $definition) {
                if (($definition['mode'] ?? 'select') !== 'select') {
                    continue;
                }
                $table = (string) $definition['table'];
                $key = (string) $definition['key'];
                $display = (string) $definition['displayField'];
                $builder = $this->db->table($table)
                    ->select([$key, $display])
                    ->orderBy($display, 'ASC');

                // If this FK is UNIQUE in the inline-created table, choices
                // already referenced there would necessarily fail validation
                // (and the database constraint). Hide them before rendering
                // the Related Create select instead of asking the user to
                // discover the conflict after submit.
                $consumerTable = trim((string) ($definition['uniqueConsumerTable'] ?? ''));
                $consumerField = trim((string) ($definition['uniqueConsumerField'] ?? ''));
                if ($consumerTable !== '' && $consumerField !== '') {
                    $usedRows = $this->db->table($consumerTable)
                        ->select($consumerField)
                        ->where($consumerField . ' IS NOT NULL', null, false)
                        ->get()
                        ->getResultArray();
                    $usedIds = array_values(array_unique(array_filter(
                        array_map(
                            static fn (array $row): string => (string) ($row[$consumerField] ?? ''),
                            $usedRows
                        ),
                        static fn (string $value): bool => $value !== ''
                    )));
                    if ($usedIds !== []) {
                        $builder->whereNotIn($key, $usedIds);
                    }
                }

                $rows = $builder->get()->getResultArray();
                foreach ($rows as $row) {
                    $result[(string) $relationField][(string) $field][] = [
                        'id' => (string) ($row[$key] ?? ''),
                        'text' => (string) ($row[$display] ?? $row[$key] ?? ''),
                    ];
                }
            }
        }
        return $result;
    }
    /** @return array<string,array<string,string>> */
    public function relationOptions(): array
    {
        return [
            'language_id' => $this->toRelationOptions($this->getLanguageLanguageIdOptions(), 'language_id'),
            'original_language_id' => $this->toRelationOptions($this->getLanguageOriginalLanguageIdOptions(), 'original_language_id'),
        ];
    }

    /**
     * Server-side option search for large relations.
     * Table, key, and descriptive fields come only from the generated whitelist.
     *
     * @return list<array{id:string,text:string}>
     */
    public function searchRelationOptions(string $field, string $query, int $limit = 20): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $limit = max(1, min(100, $limit));
        $builder = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->orderBy((string) $definition['displayField'], 'ASC')
            ->limit($limit);

        $query = trim($query);
        if ($query !== '' && $displayFields !== []) {
            $builder->groupStart();
            foreach ($displayFields as $index => $displayColumn) {
                if ($index === 0) {
                    $builder->like((string) $displayColumn, $query, 'after');
                } else {
                    $builder->orLike((string) $displayColumn, $query, 'after');
                }
            }
            $builder->groupEnd();
        }

        $rows = $builder->get()->getResultArray();
        $result = [];
        foreach ($rows as $row) {
            $result[] = [
                'id' => (string) ($row[$key] ?? ''),
                'text' => $this->formatRelationLabel($row, $definition),
            ];
        }

        return $result;
    }

    /** @return array{id:string,text:string}|null */
    public function relationOptionById(string $field, int|string $id): ?array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return null;
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $displayFields = array_values((array) ($definition['displayFields'] ?? []));
        $selectFields = array_values(array_unique(array_merge([$key], $displayFields)));
        $row = $this->db->table((string) $definition['table'])
            ->select($selectFields)
            ->where($key, $id)
            ->limit(1)
            ->get()
            ->getRowArray();

        if (!is_array($row)) {
            return null;
        }

        return [
            'id' => (string) ($row[$key] ?? ''),
            'text' => $this->formatRelationLabel($row, $definition),
        ];
    }

    /** @return array<string,string> */
    private function toRelationOptions(array $rows, string $field): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $key = (string) $definition['key'];
        $options = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $options[(string) ($row[$key] ?? '')] = $this->formatRelationLabel($row, $definition);
        }
        return $options;
    }

    private function formatRelationLabel(array $row, array $definition): string
    {
        $template = trim((string) ($definition['displayTemplate'] ?? ''));
        if ($template === '') {
            return trim((string) ($row[(string) $definition['displayField']] ?? ''));
        }

        $label = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/',
            static fn (array $match): string => (string) ($row[$match[1]] ?? ''),
            $template
        );

        return trim((string) $label);
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table film_actor.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getFilmActorByFilmId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\FilmActorModel())->childrenByForeignKey(
            'film_id',
            $parentId,
            array (
  0 => 'actor_id',
  1 => 'film_id',
  2 => 'last_update',
),
            'actor_id',
            $limit
        );
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table film_category.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getFilmCategoryByFilmId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\FilmCategoryModel())->childrenByForeignKey(
            'film_id',
            $parentId,
            array (
  0 => 'film_id',
  1 => 'category_id',
  2 => 'last_update',
),
            'film_id',
            $limit
        );
    }
    /**
     * HasMany scaffolding delegated to the Model that owns table inventory.
     * The current Model only names the relation; it no longer composes child SQL.
     */
    public function getInventoryByFilmId(int|string $parentId, int $limit = 20): array
    {
        return (new \App\Models\InventoryModel())->childrenByForeignKey(
            'film_id',
            $parentId,
            array (
  0 => 'inventory_id',
  1 => 'film_id',
  2 => 'store_id',
  3 => 'last_update',
),
            'inventory_id',
            $limit
        );
    }
    /**
     * Many-to-many scaffolding: reads actor through pivot film_actor.
     * Punto di estensione: ampliare select/orderBy senza toccare il Controller.
     */
    public function getActorViaFilmActor(int|string $parentId, int $limit = 20): array
    {
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table('film_actor p')
            ->select('r.actor_id, r.first_name')
            ->join('actor r', 'r.actor_id = p.actor_id', 'inner')
            ->where('p.film_id', $parentId)
            ->orderBy('r.first_name', 'ASC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }

    /** Attach idempotente alla pivot film_actor. */
    public function attachActor(int|string $parentId, int|string $relatedId): bool
    {
        $builder = $this->db->table('film_actor');
        $exists = $builder->where('film_id', $parentId)
            ->where('actor_id', $relatedId)
            ->countAllResults() > 0;
        return $exists || $this->db->table('film_actor')->insert([
            'film_id' => $parentId,
            'actor_id' => $relatedId,
        ]);
    }

    /** Rimuove una singola associazione dalla pivot film_actor. */
    public function detachActor(int|string $parentId, int|string $relatedId): bool
    {
        return $this->db->table('film_actor')
            ->where('film_id', $parentId)
            ->where('actor_id', $relatedId)
            ->delete();
    }

    /**
     * Sincronizza le associazioni con un diff attach/detach.
     * Does not update or delete records from table actor.
     */
    public function syncActor(int|string $parentId, array $relatedIds): bool
    {
        $relatedIds = array_values(array_unique(array_map('strval', array_filter(
            $relatedIds,
            static fn (mixed $id): bool => is_scalar($id) && trim((string) $id) !== ''
        ))));
        $existingRows = $this->db->table('film_actor')
            ->select('actor_id')
            ->where('film_id', $parentId)
            ->get()->getResultArray();
        $existing = array_map('strval', array_column($existingRows, 'actor_id'));
        $attach = array_values(array_diff($relatedIds, $existing));
        $detach = array_values(array_diff($existing, $relatedIds));

        $this->db->transBegin();
        try {
            foreach ($attach as $id) {
                if (!$this->attachActor($parentId, $id)) {
                    throw new RuntimeException('Attach pivot non riuscito.');
                }
            }
            foreach ($detach as $id) {
                if (!$this->detachActor($parentId, $id)) {
                    throw new RuntimeException('Detach pivot non riuscito.');
                }
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Sync pivot non riuscito.');
            }
            $this->db->transCommit();
            return true;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }
    /**
     * Many-to-many scaffolding: reads category through pivot film_category.
     * Punto di estensione: ampliare select/orderBy senza toccare il Controller.
     */
    public function getCategoryViaFilmCategory(int|string $parentId, int $limit = 20): array
    {
        $limit = max(1, min(200, $limit));
        $rows = $this->db->table('film_category p')
            ->select('r.category_id, r.name')
            ->join('category r', 'r.category_id = p.category_id', 'inner')
            ->where('p.film_id', $parentId)
            ->orderBy('r.name', 'ASC')
            ->limit($limit + 1)
            ->get()
            ->getResult();
        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }
        return ['rows' => $rows, 'count' => count($rows), 'hasMore' => $hasMore];
    }

    /** Attach idempotente alla pivot film_category. */
    public function attachCategory(int|string $parentId, int|string $relatedId): bool
    {
        $builder = $this->db->table('film_category');
        $exists = $builder->where('film_id', $parentId)
            ->where('category_id', $relatedId)
            ->countAllResults() > 0;
        return $exists || $this->db->table('film_category')->insert([
            'film_id' => $parentId,
            'category_id' => $relatedId,
        ]);
    }

    /** Rimuove una singola associazione dalla pivot film_category. */
    public function detachCategory(int|string $parentId, int|string $relatedId): bool
    {
        return $this->db->table('film_category')
            ->where('film_id', $parentId)
            ->where('category_id', $relatedId)
            ->delete();
    }

    /**
     * Sincronizza le associazioni con un diff attach/detach.
     * Does not update or delete records from table category.
     */
    public function syncCategory(int|string $parentId, array $relatedIds): bool
    {
        $relatedIds = array_values(array_unique(array_map('strval', array_filter(
            $relatedIds,
            static fn (mixed $id): bool => is_scalar($id) && trim((string) $id) !== ''
        ))));
        $existingRows = $this->db->table('film_category')
            ->select('category_id')
            ->where('film_id', $parentId)
            ->get()->getResultArray();
        $existing = array_map('strval', array_column($existingRows, 'category_id'));
        $attach = array_values(array_diff($relatedIds, $existing));
        $detach = array_values(array_diff($existing, $relatedIds));

        $this->db->transBegin();
        try {
            foreach ($attach as $id) {
                if (!$this->attachCategory($parentId, $id)) {
                    throw new RuntimeException('Attach pivot non riuscito.');
                }
            }
            foreach ($detach as $id) {
                if (!$this->detachCategory($parentId, $id)) {
                    throw new RuntimeException('Detach pivot non riuscito.');
                }
            }
            if (!$this->db->transStatus()) {
                throw new RuntimeException('Sync pivot non riuscito.');
            }
            $this->db->transCommit();
            return true;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }
    /** @return array<string,array<string,mixed>> */
    public function loadHasMany(int|string $parentId): array
    {
        $result = [];
        $result['film_actor__film_id'] = $this->getFilmActorByFilmId($parentId, 20);

        $result['film_category__film_id'] = $this->getFilmCategoryByFilmId($parentId, 20);

        $result['inventory__film_id'] = $this->getInventoryByFilmId($parentId, 20);

        $result['many__film_actor__film_id'] = $this->getActorViaFilmActor($parentId, 20);

        $result['many__film_category__film_id'] = $this->getCategoryViaFilmCategory($parentId, 20);
        return $result;
    }
}
