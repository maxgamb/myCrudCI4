<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\ActorInfoModel;

/**
 * Service read-only per la SQL VIEW `actor_info`.
 *
 * Responsabilità:
 * - paginated list, filters, and export;
 * - eventuale esposizione API GET;
 * - no write operations and no ServiceExtension.
 *
 * Queries remain the responsibility of ActorInfoModel.
 */
final class ActorInfoService
{
    public function __construct(private readonly ActorInfoModel $model = new ActorInfoModel())
    {
    }

    /**
     * Returns a list page using authorized filters and sorting.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows:array<int,object>,total:int,page:int,perPage:int,pagerLinks:string,sort:string,direction:string}
     */
    public function listPage(
        array $filters,
        int $page,
        int $perPage,
        string $sort,
        string $direction
    ): array {
        return $this->model->getListPage($filters, $page, $perPage, $sort, $direction);
    }

    /**
     * Returns a block of rows for cursor-based export.
     *
     * @param array<int, array<string,mixed>> $filters
     * @return array<int, array<string,mixed>>
     */
    public function exportRows(array $filters, int $limit, int|string|null $after = null): array
    {
        return $this->model->getExportRows($filters, $limit, $after);
    }

    /** @param array<int, array<string,mixed>> $filters */
    public function countExportRows(array $filters): int
    {
        return $this->model->countExportRows($filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return $this->model->exportFields();
    }

    /**
     * Returns a REST page using only authorized filters and sorting.
     *
     * @param array<string, mixed> $query
     * @param list<string> $filterable
     * @param list<string> $sortable
     * @return array{rows:array<int,object>,meta:array<string,int>,links:array<string,string|null>}
     */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        return $this->model->apiList($query, $filterable, $sortable);
    }
}
