<?php

declare(strict_types=1);

namespace App\Services;

use App\DTO\Dashboard\Kpi;
use App\Libraries\Dashboard\DashboardQuery;

/**
 * Composes Dashboard widgets.
 *
 * Existing CRUD Models are reused for record-shaped data.
 * DashboardQuery is used only for aggregate/statistical data.
 */
final class DashboardService
{
    private const CONFIG = array (
  'name' => 'main',
  'title' => 'Application Dashboard',
  'route' => 'dashboard',
  'widgets' => 
  array (
    0 => 
    array (
      'id' => 'widget_msukf4qb_1kinm',
      'type' => 'kpi_count',
      'title' => 'Film',
      'table' => 'film',
      'modelClass' => 'App\\Models\\FilmModel',
      'primaryKey' => 'film_id',
      'operation' => 'COUNT',
      'valueField' => '',
      'groupField' => '',
      'chartType' => 'bar',
      'decimals' => 0,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => '',
        'label' => '',
        'operator' => 'eq',
        'value' => '',
      ),
      'fieldLabels' => 
      array (
        'film_id' => 'Film Id',
        'title' => 'Title',
        'description' => 'Description',
        'release_year' => 'Release Year',
        'language_id' => 'Language Id',
        'original_language_id' => 'Original Language Id',
        'rental_duration' => 'Rental Duration',
        'rental_rate' => 'Rental Rate',
        'length' => 'Length',
        'replacement_cost' => 'Replacement Cost',
        'rating' => 'Rating',
        'special_features' => 'Special Features',
        'last_update' => 'Last Update',
        'uploads' => 'Uploads',
      ),
      'recentFields' => 
      array (
        0 => 'film_id',
        1 => 'title',
        2 => 'description',
        3 => 'release_year',
        4 => 'language_id',
        5 => 'original_language_id',
      ),
      'limit' => 5,
      'width' => 4,
    ),
    1 => 
    array (
      'id' => 'widget_msul4jfg_9nih6',
      'type' => 'grouped_chart',
      'title' => 'Payment',
      'table' => 'payment',
      'modelClass' => 'App\\Models\\PaymentModel',
      'primaryKey' => 'payment_id',
      'operation' => 'COUNT',
      'valueField' => '',
      'groupField' => 'customer_id',
      'chartType' => 'bar',
      'decimals' => 0,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => '',
        'label' => '',
        'operator' => 'eq',
        'value' => '',
      ),
      'fieldLabels' => 
      array (
        'payment_id' => 'Payment Id',
        'customer_id' => 'Customer Id',
        'staff_id' => 'Staff Id',
        'rental_id' => 'Rental Id',
        'amount' => 'Amount',
        'payment_date' => 'Payment Date',
        'last_update' => 'Last Update',
      ),
      'recentFields' => 
      array (
        0 => 'payment_id',
        1 => 'customer_id',
        2 => 'staff_id',
        3 => 'rental_id',
        4 => 'amount',
        5 => 'payment_date',
      ),
      'limit' => 5,
      'width' => 4,
    ),
    2 => 
    array (
      'id' => 'widget_msukfo56_hn72m',
      'type' => 'kpi_aggregate',
      'title' => 'Film',
      'table' => 'film',
      'modelClass' => 'App\\Models\\FilmModel',
      'primaryKey' => 'film_id',
      'operation' => 'SUM',
      'valueField' => 'rental_duration',
      'groupField' => '',
      'chartType' => 'bar',
      'decimals' => 2,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => 'release_year',
        'label' => 'Release Year',
        'operator' => 'gt',
        'value' => '2006',
      ),
      'fieldLabels' => 
      array (
        'film_id' => 'Film Id',
        'title' => 'Title',
        'description' => 'Description',
        'release_year' => 'Release Year',
        'language_id' => 'Language Id',
        'original_language_id' => 'Original Language Id',
        'rental_duration' => 'Rental Duration',
        'rental_rate' => 'Rental Rate',
        'length' => 'Length',
        'replacement_cost' => 'Replacement Cost',
        'rating' => 'Rating',
        'special_features' => 'Special Features',
        'last_update' => 'Last Update',
        'uploads' => 'Uploads',
      ),
      'recentFields' => 
      array (
        0 => 'film_id',
        1 => 'title',
        2 => 'description',
        3 => 'release_year',
        4 => 'language_id',
        5 => 'original_language_id',
      ),
      'limit' => 5,
      'width' => 4,
    ),
    3 => 
    array (
      'id' => 'widget_msukgidp_o6id4',
      'type' => 'grouped_chart',
      'title' => 'Film',
      'table' => 'film',
      'modelClass' => 'App\\Models\\FilmModel',
      'primaryKey' => 'film_id',
      'operation' => 'COUNT',
      'valueField' => '',
      'groupField' => 'release_year',
      'chartType' => 'bar',
      'decimals' => 0,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => '',
        'label' => '',
        'operator' => 'eq',
        'value' => '',
      ),
      'fieldLabels' => 
      array (
        'film_id' => 'Film Id',
        'title' => 'Title',
        'description' => 'Description',
        'release_year' => 'Release Year',
        'language_id' => 'Language Id',
        'original_language_id' => 'Original Language Id',
        'rental_duration' => 'Rental Duration',
        'rental_rate' => 'Rental Rate',
        'length' => 'Length',
        'replacement_cost' => 'Replacement Cost',
        'rating' => 'Rating',
        'special_features' => 'Special Features',
        'last_update' => 'Last Update',
        'uploads' => 'Uploads',
      ),
      'recentFields' => 
      array (
        0 => 'film_id',
        1 => 'title',
        2 => 'description',
        3 => 'release_year',
        4 => 'language_id',
        5 => 'original_language_id',
      ),
      'limit' => 5,
      'width' => 4,
    ),
    4 => 
    array (
      'id' => 'widget_msukgx5e_dq4ej',
      'type' => 'recent',
      'title' => 'Film',
      'table' => 'film',
      'modelClass' => 'App\\Models\\FilmModel',
      'primaryKey' => 'film_id',
      'operation' => 'COUNT',
      'valueField' => '',
      'groupField' => '',
      'chartType' => 'bar',
      'decimals' => 0,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => 'release_year',
        'label' => 'Release Year',
        'operator' => 'gt',
        'value' => '2000',
      ),
      'fieldLabels' => 
      array (
        'film_id' => 'Film Id',
        'title' => 'Title',
        'description' => 'Description',
        'release_year' => 'Release Year',
        'language_id' => 'Language Id',
        'original_language_id' => 'Original Language Id',
        'rental_duration' => 'Rental Duration',
        'rental_rate' => 'Rental Rate',
        'length' => 'Length',
        'replacement_cost' => 'Replacement Cost',
        'rating' => 'Rating',
        'special_features' => 'Special Features',
        'last_update' => 'Last Update',
        'uploads' => 'Uploads',
      ),
      'recentFields' => 
      array (
        0 => 'film_id',
        1 => 'title',
        2 => 'description',
        3 => 'release_year',
        4 => 'language_id',
        5 => 'original_language_id',
      ),
      'limit' => 5,
      'width' => 4,
    ),
    5 => 
    array (
      'id' => 'widget_msukh5ob_3he4s',
      'type' => 'quick_link',
      'title' => 'Film',
      'table' => 'film',
      'modelClass' => 'App\\Models\\FilmModel',
      'primaryKey' => 'film_id',
      'operation' => 'COUNT',
      'valueField' => '',
      'groupField' => '',
      'chartType' => 'bar',
      'decimals' => 0,
      'prefix' => '',
      'suffix' => '',
      'filter' => 
      array (
        'field' => '',
        'label' => '',
        'operator' => 'eq',
        'value' => '',
      ),
      'fieldLabels' => 
      array (
        'film_id' => 'Film Id',
        'title' => 'Title',
        'description' => 'Description',
        'release_year' => 'Release Year',
        'language_id' => 'Language Id',
        'original_language_id' => 'Original Language Id',
        'rental_duration' => 'Rental Duration',
        'rental_rate' => 'Rental Rate',
        'length' => 'Length',
        'replacement_cost' => 'Replacement Cost',
        'rating' => 'Rating',
        'special_features' => 'Special Features',
        'last_update' => 'Last Update',
        'uploads' => 'Uploads',
      ),
      'recentFields' => 
      array (
        0 => 'film_id',
        1 => 'title',
        2 => 'description',
        3 => 'release_year',
        4 => 'language_id',
        5 => 'original_language_id',
      ),
      'limit' => 5,
      'width' => 4,
    ),
  ),
);

    public function __construct(private ?DashboardQuery $query = null)
    {
        $this->query ??= new DashboardQuery();
    }

    /** @return array{title:string,widgets:list<array<string,mixed>>} */
    public function build(): array
    {
        $widgets = [];

        foreach ((array) self::CONFIG['widgets'] as $widget) {
            $type = (string) ($widget['type'] ?? '');
            $modelClass = (string) ($widget['modelClass'] ?? '');
            $filter = (array) ($widget['filter'] ?? []);

            if ($type === 'kpi_count') {
                $value = $this->query->count((string) $widget['table'], $filter);
                $widgets[] = [
                    'type' => 'kpi',
                    'width' => (int) $widget['width'],
                    'data' => new Kpi(
                        (string) $widget['title'],
                        $value,
                        $this->formatNumber(
                            $value,
                            (int) ($widget['decimals'] ?? 0),
                            (string) ($widget['prefix'] ?? ''),
                            (string) ($widget['suffix'] ?? '')
                        )
                    ),
                    'filter' => $filter,
                ];
                continue;
            }

            if ($type === 'kpi_aggregate') {
                $operation = (string) $widget['operation'];
                $value = $this->query->aggregate(
                    (string) $widget['table'],
                    (string) $widget['valueField'],
                    $operation,
                    $filter
                );

                $widgets[] = [
                    'type' => 'kpi',
                    'width' => (int) $widget['width'],
                    'data' => new Kpi(
                        (string) $widget['title'],
                        $value,
                        $this->formatNumber(
                            $value,
                            (int) ($widget['decimals'] ?? 2),
                            (string) ($widget['prefix'] ?? ''),
                            (string) ($widget['suffix'] ?? '')
                        )
                    ),
                    'operation' => $operation,
                    'field' => (string) $widget['valueField'],
                    'filter' => $filter,
                ];
                continue;
            }

            if ($type === 'grouped_chart') {
                $points = $this->query->grouped(
                    (string) $widget['table'],
                    (string) $widget['groupField'],
                    (string) $widget['operation'],
                    (string) $widget['valueField'],
                    (int) $widget['limit'],
                    $filter
                );

                $widgets[] = [
                    'type' => 'chart',
                    'title' => (string) $widget['title'],
                    'width' => (int) $widget['width'],
                    'chartType' => (string) $widget['chartType'],
                    'operation' => (string) $widget['operation'],
                    'groupField' => (string) $widget['groupField'],
                    'groupLabel' => (string) (($widget['fieldLabels'][$widget['groupField']] ?? $widget['groupField'])),
                    'valueField' => (string) $widget['valueField'],
                    'valueLabel' => (string) (($widget['fieldLabels'][$widget['valueField']] ?? $widget['valueField'])),
                    'points' => $points,
                    'filter' => $filter,
                ];
                continue;
            }

            if ($type === 'recent') {
                if (!class_exists($modelClass)) {
                    continue;
                }

                $model = new $modelClass();
                $this->applyModelFilter($model, $filter);

                $primaryKey = (string) ($widget['primaryKey'] ?? 'id');
                $records = $model
                    ->orderBy($primaryKey, 'DESC')
                    ->findAll((int) $widget['limit']);

                $widgets[] = [
                    'type' => 'recent',
                    'title' => (string) $widget['title'],
                    'width' => (int) $widget['width'],
                    'table' => (string) $widget['table'],
                    'records' => $records,
                    'fields' => (array) ($widget['recentFields'] ?? []),
                    'labels' => (array) ($widget['fieldLabels'] ?? []),
                    'filter' => $filter,
                ];
                continue;
            }

            if ($type === 'quick_link') {
                $widgets[] = [
                    'type' => 'quick_link',
                    'title' => (string) $widget['title'],
                    'width' => (int) $widget['width'],
                    'table' => (string) $widget['table'],
                ];
            }
        }

        return [
            'title' => (string) self::CONFIG['title'],
            'widgets' => $widgets,
        ];
    }

    private function formatNumber(
        int|float $value,
        int $decimals,
        string $prefix,
        string $suffix
    ): string {
        $number = number_format($value, max(0, min(4, $decimals)), '.', ',');

        return trim($prefix . $number . $suffix);
    }

    private function applyModelFilter(object $model, array $filter): void
    {
        $field = trim((string) ($filter['field'] ?? ''));
        $operator = (string) ($filter['operator'] ?? 'eq');
        $value = $filter['value'] ?? null;

        if ($field === '' || $value === null || $value === '') {
            return;
        }

        match ($operator) {
            'eq' => $model->where($field, $value),
            'neq' => $model->where($field . ' !=', $value),
            'gt' => $model->where($field . ' >', $value),
            'gte' => $model->where($field . ' >=', $value),
            'lt' => $model->where($field . ' <', $value),
            'lte' => $model->where($field . ' <=', $value),
            'contains' => $model->like($field, (string) $value, 'both'),
            'starts_with' => $model->like($field, (string) $value, 'after'),
            default => null,
        };
    }
}