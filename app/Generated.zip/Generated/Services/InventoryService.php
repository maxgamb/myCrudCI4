<?php

declare(strict_types=1);

namespace App\Services;

use App\Services\Extensions\InventoryServiceExtension;
use App\Models\InventoryModel;
use RuntimeException;

/**
 * Service applicativo per la risorsa `inventory`.
 *
 * Responsabilità:
 * - coordinates CRUD operations and transactions delegated to the Model;
 * - prepares application data (passwords, automatic dates, DB-managed fields);
 * - coordina hasMany e many-to-many senza comporre SQL;
 * - invoca gli hook custom definiti nel ServiceExtension persistente;
 *
 * Queries remain the responsibility of InventoryModel.
 */
final class InventoryService
{
    use InventoryServiceExtension;

    private const PASSWORD_FIELDS = array (
);
    private const AUTOMATIC_DATE_FIELDS = array (
);
    private const DATABASE_MANAGED_FIELDS = array (
  0 => 'last_update',
);
    private const NULLABLE_FOREIGN_KEY_FIELDS = array (
);
    public function __construct(private readonly InventoryModel $model = new InventoryModel())
    {
    }

    /**
     * Returns record details or throws an application error.
     *
     * @throws RuntimeException If the record does not exist.
     */
    public function find(int|string $id): object
    {
        $record = $this->model->getDetail($id);
        if (!is_object($record)) {
            throw new RuntimeException('Record not found.');
        }
        return $record;
    }
    /**
     * Returns a list page using authorized filters and sorting.
     *
     * @param array<int, array<string, mixed>> $filters
     * @return array{rows:array<int,object>,total:int,page:int,perPage:int,pagerLinks:string,sort:string,direction:string}
     */
    public function listPage(
        array $filters,
        int $page,
        int $perPage,
        string $sort,
        string $direction
    ): array {
        return $this->model->getListPage($filters, $page, $perPage, $sort, $direction);
    }

    /**
     * Returns a block of rows for cursor-based export.
     *
     * @param array<int, array<string,mixed>> $filters
     * @return array<int, array<string,mixed>>
     */
    public function exportRows(array $filters, int $limit, int|string|null $after = null): array
    {
        return $this->model->getExportRows($filters, $limit, $after);
    }

    /** @param array<int, array<string,mixed>> $filters */
    public function countExportRows(array $filters): int
    {
        return $this->model->countExportRows($filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return $this->model->exportFields();
    }

    /**
     * Returns a REST page using only authorized filters and sorting.
     *
     * @param array<string, mixed> $query
     * @param list<string> $filterable
     * @param list<string> $sortable
     * @return array{rows:array<int,object>,meta:array<string,int>,links:array<string,string|null>}
     */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        return $this->model->apiList($query, $filterable, $sortable);
    }
    /** @return array<string, array<string,string>> */
    public function relationOptions(): array
    {
        return $this->model->relationOptions();
    }
    /**
     * Returns foreign-key options for inline-created parents.
     *
     * @return array<string, array<string, list<array{id:string,text:string}>>>
     */
    public function relatedCreateRelationOptions(): array
    {
        return $this->model->relatedCreateRelationOptions();
    }
    /** @return list<array{id:string,text:string}> */
    public function searchRelationOptions(string $field, string $query, int $limit = 20): array
    {
        return $this->model->searchRelationOptions($field, $query, $limit);
    }

    /** @return array{id:string,text:string}|null */
    public function relationOptionById(string $field, int|string $id): ?array
    {
        return $this->model->relationOptionById($field, $id);
    }
    /**
     * Loads configured child-relation previews for the View.
     *
     * @return array<string, array<string,mixed>>
     */
    public function loadHasMany(int|string $parentId): array
    {
        return $this->model->loadHasMany($parentId);
    }
    /**
     * Creates the main record and configured atomic relations.
     *
     * Ordine applicativo: normalizzazione standard, eventuale beforeCreate(),
     * persistenza atomica nel Model, eventuale afterCreate().
     *
     * @param array<string, mixed> $data Main record data.
     * @param array<string, array<string, mixed>> $related Parent creati inline.
     * @param array<string, list<int|string>> $manyToMany Many-to-many associations.
     * @param array<string, array<string,mixed>> $manyToManyNew New target records to create atomically.
     * @return int|string Created record identifier.
     */
    public function create(
        array $data,
        array $related = [],
        array $manyToMany = [],
        array $manyToManyNew = []
    ): int|string {
        $data = $this->prepareData($data, false);
        $data = $this->beforeCreate($data);
        $id = $this->model->createRecord($data, $related, $manyToMany, $manyToManyNew);
        $this->afterCreate($id, $data);

        return $id;
    }
    /**
     * Updates the record and synchronizes configured many-to-many relations.
     *
     * @param array<string, mixed> $data
     * @param array<string, list<int|string>> $manyToMany
     * @param array<string, array<string,mixed>> $manyToManyNew
     * @throws RuntimeException If the update cannot be completed.
     */
    public function update(
        int|string $id,
        array $data,
        array $manyToMany = [],
        array $manyToManyNew = []
    ): void {
        $data = $this->prepareData($data, true);
        $data = $this->beforeUpdate($id, $data);
        if (!$this->model->updateRecordWithManyToMany($id, $data, $manyToMany, $manyToManyNew)) {
            throw new RuntimeException(implode(' ', $this->model->errors()) ?: 'Update failed.');
        }
        $this->afterUpdate($id, $data);
    }
    /**
     * Normalizes application data only, without running queries.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function prepareData(array $data, bool $isUpdate): array
    {
        foreach (self::DATABASE_MANAGED_FIELDS as $field) {
            unset($data[$field]);
        }

        if (!$isUpdate) {
            foreach (self::AUTOMATIC_DATE_FIELDS as $field => $format) {
                if (!isset($data[$field]) || trim((string) $data[$field]) === '') {
                    $data[$field] = date($format);
                }
            }
        }

        foreach (self::NULLABLE_FOREIGN_KEY_FIELDS as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            $value = $data[$field];
            if ($value !== null && is_scalar($value) && trim((string) $value) === '') {
                $data[$field] = null;
            }
        }

        foreach (self::PASSWORD_FIELDS as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }

            $value = trim((string) $data[$field]);
            if ($value === '') {
                if ($isUpdate) {
                    unset($data[$field]);
                }
                continue;
            }

            $data[$field] = password_hash($value, PASSWORD_DEFAULT);
        }

        return $data;
    }
    /**
     * Deletes the record according to the Model soft-delete policy.
     *
     * @throws RuntimeException If deletion fails.
     */
    public function delete(int|string $id): void
    {
        $this->beforeDelete($id);
        if (!$this->model->delete($id)) {
            throw new RuntimeException('Delete failed.');
        }
        $this->model->clearListCountCache();
        $this->afterDelete($id);
    }
}
