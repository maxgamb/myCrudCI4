<?= $this->extend('layouts/default_app') ?>
<?= $this->section('content') ?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <div class="text-muted small text-uppercase">Dashboard</div>
            <h1 class="h3 mb-0"><?= esc((string) ($dashboard['title'] ?? 'Dashboard')) ?></h1>
        </div>
    </div>

    <div class="row g-3 align-items-start">
        <?php foreach ((array) ($dashboard['widgets'] ?? []) as $index => $widget): ?>
            <?php
            $width = max(1, min(12, (int) ($widget['width'] ?? 4)));
            $filter = (array) ($widget['filter'] ?? []);
            $hasFilter = trim((string) ($filter['field'] ?? '')) !== '';
            ?>
            <div class="col-12 col-lg-<?= $width ?>">
                <?php if (($widget['type'] ?? '') === 'kpi'): ?>
                    <?php $kpi = $widget['data']; ?>
                    <div class="card shadow-sm">
                        <div class="card-body py-3">
                            <div class="d-flex justify-content-between align-items-start gap-2">
                                <div>
                                    <div class="text-muted small"><?= esc($kpi->label) ?></div>
                                    <div class="h2 fw-semibold mb-0 mt-1"><?= esc($kpi->formattedValue) ?></div>
                                </div>
                                <i class="bi bi-speedometer2 text-muted fs-4"></i>
                            </div>

                            <?php if (!empty($widget['operation'])): ?>
                                <div class="small text-muted mt-2">
                                    <?= esc((string) $widget['operation']) ?>
                                    <?= esc((string) ($widget['field'] ?? '')) ?>
                                </div>
                            <?php endif ?>

                            <?php if ($hasFilter): ?>
                                <div class="small text-muted mt-2">
                                    <i class="bi bi-funnel me-1"></i>
                                    <?= esc((string) ($filter['label'] ?? $filter['field'])) ?>
                                    <?= esc((string) $filter['operator']) ?>
                                    <?= esc((string) $filter['value']) ?>
                                </div>
                            <?php endif ?>
                        </div>
                    </div>

                <?php elseif (($widget['type'] ?? '') === 'chart'): ?>
                    <?php
                    $points = (array) ($widget['points'] ?? []);
                    $labels = array_map(static fn ($point): string => (string) $point->label, $points);
                    $values = array_map(static fn ($point): int|float => $point->value, $points);
                    ?>
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-start gap-2">
                                <div>
                                    <strong><?= esc((string) ($widget['title'] ?? 'Chart')) ?></strong>
                                    <div class="small text-muted">
                                        <?= esc((string) ($widget['operation'] ?? 'COUNT')) ?>
                                        by <?= esc((string) ($widget['groupLabel'] ?? $widget['groupField'] ?? '')) ?>
                                    </div>
                                </div>
                                <?php if ($hasFilter): ?>
                                    <span class="badge text-bg-light border">
                                        <i class="bi bi-funnel me-1"></i>
                                        <?= esc((string) ($filter['label'] ?? $filter['field'])) ?>
                                    </span>
                                <?php endif ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <div style="height: 300px;">
                                <canvas
                                    data-dashboard-chart
                                    data-chart-type="<?= esc((string) ($widget['chartType'] ?? 'bar')) ?>"
                                    data-labels="<?= esc(json_encode($labels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>"
                                    data-values="<?= esc(json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>"
                                    aria-label="<?= esc((string) ($widget['title'] ?? 'Dashboard chart')) ?>"
                                    role="img"
                                ></canvas>
                            </div>
                        </div>
                    </div>

                <?php elseif (($widget['type'] ?? '') === 'recent'): ?>
                    <?php
                    $recentFields = (array) ($widget['fields'] ?? []);
                    $fieldLabels = (array) ($widget['labels'] ?? []);
                    ?>
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= esc((string) ($widget['title'] ?? 'Recent records')) ?></strong>
                                <?php if ($hasFilter): ?>
                                    <div class="small text-muted">
                                        <i class="bi bi-funnel me-1"></i>
                                        <?= esc((string) ($filter['label'] ?? $filter['field'])) ?>
                                        <?= esc((string) $filter['operator']) ?>
                                        <?= esc((string) $filter['value']) ?>
                                    </div>
                                <?php endif ?>
                            </div>
                            <a class="btn btn-sm btn-outline-primary" href="<?= site_url((string) $widget['table']) ?>">
                                View all
                            </a>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                    <tr>
                                        <?php foreach ($recentFields as $field): ?>
                                            <th><?= esc((string) ($fieldLabels[$field] ?? $field)) ?></th>
                                        <?php endforeach ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ((array) ($widget['records'] ?? []) as $record): ?>
                                        <?php $row = is_object($record) ? null : (array) $record; ?>
                                        <tr>
                                            <?php foreach ($recentFields as $field): ?>
                                                <?php
                                                $value = is_object($record)
                                                    ? ($record->{$field} ?? null)
                                                    : ($row[$field] ?? null);
                                                ?>
                                                <td><?= esc(is_scalar($value) || $value === null ? (string) $value : '') ?></td>
                                            <?php endforeach ?>
                                        </tr>
                                    <?php endforeach ?>

                                    <?php if (($widget['records'] ?? []) === []): ?>
                                        <tr>
                                            <td colspan="<?= max(1, count($recentFields)) ?>" class="text-muted text-center py-3">
                                                No records.
                                            </td>
                                        </tr>
                                    <?php endif ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                <?php elseif (($widget['type'] ?? '') === 'quick_link'): ?>
                    <a href="<?= site_url((string) $widget['table']) ?>" class="card shadow-sm text-decoration-none">
                        <div class="card-body py-3 d-flex align-items-center justify-content-between">
                            <strong><?= esc((string) ($widget['title'] ?? 'Open')) ?></strong>
                            <i class="bi bi-arrow-right fs-4"></i>
                        </div>
                    </a>
                <?php endif ?>
            </div>
        <?php endforeach ?>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-dashboard-chart]').forEach((canvas) => {
        const labels = JSON.parse(canvas.dataset.labels || '[]');
        const values = JSON.parse(canvas.dataset.values || '[]');
        const type = canvas.dataset.chartType || 'bar';

        new Chart(canvas, {
            type,
            data: {
                labels,
                datasets: [{
                    label: canvas.getAttribute('aria-label') || 'Dashboard',
                    data: values
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    });
});
</script>
<?= $this->endSection() ?>