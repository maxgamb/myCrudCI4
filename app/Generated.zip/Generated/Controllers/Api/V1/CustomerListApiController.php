<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\CustomerListResource;
use App\Controllers\Api\BaseApiController;
use App\Services\CustomerListService;
use Throwable;

/**
 * Read-only API for SQL VIEW `customer_list`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class CustomerListApiController extends BaseApiController
{
    private const API_TABLE = 'customer_list';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly CustomerListService $service = new CustomerListService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, CustomerListResource::filterableFields(), CustomerListResource::sortableFields());
            return $this->success(CustomerListResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
