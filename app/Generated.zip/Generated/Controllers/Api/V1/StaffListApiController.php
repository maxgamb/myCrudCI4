<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\StaffListResource;
use App\Controllers\Api\BaseApiController;
use App\Services\StaffListService;
use Throwable;

/**
 * Read-only API for SQL VIEW `staff_list`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class StaffListApiController extends BaseApiController
{
    private const API_TABLE = 'staff_list';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly StaffListService $service = new StaffListService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, StaffListResource::filterableFields(), StaffListResource::sortableFields());
            return $this->success(StaffListResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
