<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\NicerButSlowerFilmListResource;
use App\Controllers\Api\BaseApiController;
use App\Services\NicerButSlowerFilmListService;
use Throwable;

/**
 * Read-only API for SQL VIEW `nicer_but_slower_film_list`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class NicerButSlowerFilmListApiController extends BaseApiController
{
    private const API_TABLE = 'nicer_but_slower_film_list';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly NicerButSlowerFilmListService $service = new NicerButSlowerFilmListService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, NicerButSlowerFilmListResource::filterableFields(), NicerButSlowerFilmListResource::sortableFields());
            return $this->success(NicerButSlowerFilmListResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
