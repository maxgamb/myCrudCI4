<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\FilmListResource;
use App\Controllers\Api\BaseApiController;
use App\Services\FilmListService;
use Throwable;

/**
 * Read-only API for SQL VIEW `film_list`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class FilmListApiController extends BaseApiController
{
    private const API_TABLE = 'film_list';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly FilmListService $service = new FilmListService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, FilmListResource::filterableFields(), FilmListResource::sortableFields());
            return $this->success(FilmListResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
