<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\SalesByFilmCategoryResource;
use App\Controllers\Api\BaseApiController;
use App\Services\SalesByFilmCategoryService;
use Throwable;

/**
 * Read-only API for SQL VIEW `sales_by_film_category`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class SalesByFilmCategoryApiController extends BaseApiController
{
    private const API_TABLE = 'sales_by_film_category';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly SalesByFilmCategoryService $service = new SalesByFilmCategoryService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, SalesByFilmCategoryResource::filterableFields(), SalesByFilmCategoryResource::sortableFields());
            return $this->success(SalesByFilmCategoryResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
