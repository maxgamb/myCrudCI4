<?php

declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\API\Resources\ActorInfoResource;
use App\Controllers\Api\BaseApiController;
use App\Services\ActorInfoService;
use Throwable;

/**
 * Read-only API for SQL VIEW `actor_info`.
 * Exposes only GET operations compatible with generated capabilities.
 */
final class ActorInfoApiController extends BaseApiController
{
    private const API_TABLE = 'actor_info';
    private const UPLOAD_FIELDS = array (
);

    public function __construct(private readonly ActorInfoService $service = new ActorInfoService())
    {
    }

    public function index()
    {
        try {
            $query = (array) $this->request->getGet();
            $query['perPage'] = $this->safePerPage();
            $result = $this->service->apiList($query, ActorInfoResource::filterableFields(), ActorInfoResource::sortableFields());
            return $this->success(ActorInfoResource::collection($result['rows']), $result['meta'], $result['links']);
        } catch (Throwable $e) {
            return $this->internalError($e);
        }
    }
}
