<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\DashboardService;

final class DashboardController extends BaseController
{
    public function index(): string
    {
        $dashboard = (new DashboardService())->build();

        return view('dashboard/index', [
            'title' => $dashboard['title'] ?? 'Application Dashboard',
            'dashboard' => $dashboard,
        ]);
    }
}