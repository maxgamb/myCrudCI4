<?php

declare(strict_types=1);

namespace App\Validation;

/** Regole server-side generate secondo le capability effettive del CRUD. */
final class FilmCategoryRules
{
    /** @return array<string,string> */
    public static function createRules(): array
    {
        return array (
  'film_id' => 'required|integer|is_not_unique[film.film_id]',
  'category_id' => 'required|integer|is_not_unique[category.category_id]',
);
    }
    /** @return array<string,array<string,string>> */
    public static function relatedCreateRules(): array
    {
        return array (
  'category_id' => 
  array (
    'name' => 'required|max_length[25]',
  ),
);
    }

    /** @return array<string,array<string,string>> */
    public static function manyToManyRelatedCreateRules(): array
    {
        return array (
);
    }
    /** @return array<string,string> */
    public static function messages(): array
    {
        return [];
    }
}
