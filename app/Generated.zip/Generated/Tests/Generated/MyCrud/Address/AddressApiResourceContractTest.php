<?php

declare(strict_types=1);

namespace Tests\Generated\MyCrud\Address;

use App\API\Resources\AddressResource;
use CodeIgniter\Test\CIUnitTestCase;

/**
 * Contract test della Resource REST: puro, senza accesso al database.
 */
final class AddressApiResourceContractTest extends CIUnitTestCase
{
    private const READABLE = array (
  0 => 'address_id',
  1 => 'address',
  2 => 'address2',
  3 => 'district',
  4 => 'city_id',
  5 => 'postal_code',
  6 => 'phone',
  7 => 'last_update',
  8 => 'city_id__label',
);
    private const WRITABLE = array (
  0 => 'address',
  1 => 'address2',
  2 => 'district',
  3 => 'city_id',
  4 => 'postal_code',
  5 => 'phone',
);

    public function testResourceMakeExposesOnlyReadableFields(): void
    {
        $source = [];
        foreach (self::READABLE as $field) {
            $source[$field] = 'readable-' . $field;
        }
        $source['__unknown_field__'] = 'must-not-survive';

        $result = AddressResource::make($source);

        $this->assertSame(
            array_values(self::READABLE),
            array_values(array_keys($result))
        );
        $this->assertArrayNotHasKey('__unknown_field__', $result);
    }

    public function testWritableDataDropsUnknownAndReadOnlyFields(): void
    {
        $payload = [];
        foreach (self::WRITABLE as $field) {
            $payload[$field] = 'allowed-' . $field;
        }
        $payload['__unknown_field__'] = 'must-not-survive';

        $filtered = AddressResource::writableData($payload);

        $this->assertSame(
            array_values(self::WRITABLE),
            array_values(array_keys($filtered))
        );
        $this->assertArrayNotHasKey('__unknown_field__', $filtered);
    }
}
