<?php

declare(strict_types=1);

namespace Tests\Generated\MyCrud\Category;

use App\API\Resources\CategoryResource;
use CodeIgniter\Test\CIUnitTestCase;

/**
 * Contract test della Resource REST: puro, senza accesso al database.
 */
final class CategoryApiResourceContractTest extends CIUnitTestCase
{
    private const READABLE = array (
  0 => 'category_id',
  1 => 'name',
  2 => 'last_update',
);
    private const WRITABLE = array (
  0 => 'name',
);

    public function testResourceMakeExposesOnlyReadableFields(): void
    {
        $source = [];
        foreach (self::READABLE as $field) {
            $source[$field] = 'readable-' . $field;
        }
        $source['__unknown_field__'] = 'must-not-survive';

        $result = CategoryResource::make($source);

        $this->assertSame(
            array_values(self::READABLE),
            array_values(array_keys($result))
        );
        $this->assertArrayNotHasKey('__unknown_field__', $result);
    }

    public function testWritableDataDropsUnknownAndReadOnlyFields(): void
    {
        $payload = [];
        foreach (self::WRITABLE as $field) {
            $payload[$field] = 'allowed-' . $field;
        }
        $payload['__unknown_field__'] = 'must-not-survive';

        $filtered = CategoryResource::writableData($payload);

        $this->assertSame(
            array_values(self::WRITABLE),
            array_values(array_keys($filtered))
        );
        $this->assertArrayNotHasKey('__unknown_field__', $filtered);
    }
}
