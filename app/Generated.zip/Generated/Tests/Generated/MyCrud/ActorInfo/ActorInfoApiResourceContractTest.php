<?php

declare(strict_types=1);

namespace Tests\Generated\MyCrud\ActorInfo;

use App\API\Resources\ActorInfoResource;
use CodeIgniter\Test\CIUnitTestCase;

/**
 * Contract test della Resource REST: puro, senza accesso al database.
 */
final class ActorInfoApiResourceContractTest extends CIUnitTestCase
{
    private const READABLE = array (
  0 => 'actor_id',
  1 => 'first_name',
  2 => 'last_name',
  3 => 'film_info',
);
    private const WRITABLE = array (
);

    public function testResourceMakeExposesOnlyReadableFields(): void
    {
        $source = [];
        foreach (self::READABLE as $field) {
            $source[$field] = 'readable-' . $field;
        }
        $source['__unknown_field__'] = 'must-not-survive';

        $result = ActorInfoResource::make($source);

        $this->assertSame(
            array_values(self::READABLE),
            array_values(array_keys($result))
        );
        $this->assertArrayNotHasKey('__unknown_field__', $result);
    }

}
