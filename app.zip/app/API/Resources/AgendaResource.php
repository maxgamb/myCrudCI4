<?php

declare(strict_types=1);

namespace App\API\Resources;

/** Serializza la risorsa agenda secondo la configurazione del Builder. */
final class AgendaResource
{
    private const READABLE = array (
  0 => 'preno_id',
  1 => 'hotel_id',
  2 => 'preno_in_data',
  3 => 'preno_importo',
  4 => 'preno_impoto_mod',
  5 => 'preno_dal',
  6 => 'preno_al',
  7 => 'preno_n_notti',
  8 => 'preno_arr_ore',
  9 => 'preno_trattamento',
  10 => 't1',
  11 => 'q1',
  12 => 'p1',
  13 => 't2',
  14 => 'q2',
  15 => 'p2',
  16 => 't3',
  17 => 'q3',
  18 => 'p3',
  19 => 't4',
  20 => 'q4',
  21 => 'p4',
  22 => 't5',
  23 => 'q5',
  24 => 'p5',
  25 => 't6',
  26 => 'q6',
  27 => 'p6',
  28 => 'preno_nome',
  29 => 'preno_cogno',
  30 => 'preno_agenzia',
  31 => 'voucher_id',
  32 => 'ota_voucher',
  33 => 'allotment_id',
  34 => 'preno_cc_tip',
  35 => 'preno_cc_n',
  36 => 'preno_cc_scad',
  37 => 'preno_tel',
  38 => 'preno_fax',
  39 => 'preno_email',
  40 => 'preno_mercato',
  41 => 'nazione_iso2',
  42 => 'preno_note',
  43 => 'preno_doc_fax',
  44 => 'preno_doc_email',
  45 => 'preno_doc_form',
  46 => 'preno_doc_mail',
  47 => 'preno_doc_vaglia',
  48 => 'preno_doc_woucher',
  49 => 'preno_pag_modalita',
  50 => 'preno_caparra',
  51 => 'preno_stato',
  52 => 'data_opzione',
  53 => 'cancella_user',
  54 => 'cancella_pass',
  55 => 'agenda_utente_id',
  56 => 'agenzie_agenzia_tipologia',
);
    private const WRITABLE = array (
  0 => 'hotel_id',
  1 => 'preno_in_data',
  2 => 'preno_importo',
  3 => 'preno_impoto_mod',
  4 => 'preno_dal',
  5 => 'preno_al',
  6 => 'preno_n_notti',
  7 => 'preno_arr_ore',
  8 => 'preno_trattamento',
  9 => 't1',
  10 => 'q1',
  11 => 'p1',
  12 => 't2',
  13 => 'q2',
  14 => 'p2',
  15 => 't3',
  16 => 'q3',
  17 => 'p3',
  18 => 't4',
  19 => 'q4',
  20 => 'p4',
  21 => 't5',
  22 => 'q5',
  23 => 'p5',
  24 => 't6',
  25 => 'q6',
  26 => 'p6',
  27 => 'preno_nome',
  28 => 'preno_cogno',
  29 => 'preno_agenzia',
  30 => 'voucher_id',
  31 => 'ota_voucher',
  32 => 'allotment_id',
  33 => 'preno_cc_tip',
  34 => 'preno_cc_n',
  35 => 'preno_cc_scad',
  36 => 'preno_tel',
  37 => 'preno_fax',
  38 => 'preno_email',
  39 => 'preno_mercato',
  40 => 'nazione_iso2',
  41 => 'preno_note',
  42 => 'preno_doc_fax',
  43 => 'preno_doc_email',
  44 => 'preno_doc_form',
  45 => 'preno_doc_mail',
  46 => 'preno_doc_vaglia',
  47 => 'preno_doc_woucher',
  48 => 'preno_pag_modalita',
  49 => 'preno_caparra',
  50 => 'preno_stato',
  51 => 'data_opzione',
  52 => 'cancella_user',
  53 => 'cancella_pass',
  54 => 'agenda_utente_id',
);
    private const FILTERABLE = array (
  0 => 'preno_id',
  1 => 'hotel_id',
  2 => 'preno_in_data',
  3 => 'preno_dal',
  4 => 'preno_al',
  5 => 'preno_cogno',
  6 => 'preno_agenzia',
  7 => 'voucher_id',
  8 => 'preno_stato',
);
    private const SORTABLE = array (
  0 => 'preno_id',
  1 => 'hotel_id',
  2 => 'preno_in_data',
  3 => 'preno_dal',
  4 => 'preno_al',
  5 => 'preno_cogno',
  6 => 'preno_agenzia',
  7 => 'voucher_id',
  8 => 'preno_stato',
);

    public static function make(object|array $record): array
    {
        if (is_array($record)) {
            $source = $record;
        } elseif (method_exists($record, 'toRawArray')) {
            $source = $record->toRawArray();
        } elseif (method_exists($record, 'toArray')) {
            $source = $record->toArray();
        } else {
            $source = get_object_vars($record);
        }

        return array_intersect_key($source, array_flip(self::READABLE));
    }

    public static function collection(array $records): array
    {
        return array_map(static fn (object|array $record): array => self::make($record), $records);
    }

    public static function writableData(array $data): array
    {
        return array_intersect_key($data, array_flip(self::WRITABLE));
    }

    public static function filterableFields(): array
    {
        return self::FILTERABLE;
    }

    public static function sortableFields(): array
    {
        return self::SORTABLE;
    }
}
