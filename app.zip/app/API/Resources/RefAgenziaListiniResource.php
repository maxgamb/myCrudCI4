<?php

declare(strict_types=1);

namespace App\API\Resources;

/** Serializza la risorsa ref_agenzia_listini secondo la configurazione del Builder. */
final class RefAgenziaListiniResource
{
    private const READABLE = array (
  0 => 'ref_agenzia_listini_id',
  1 => 'agenzia_listini_id',
  2 => 'agenzia_id',
  3 => 'hotel_id',
  4 => 'agenzia_limite_vendita',
  5 => 'agenzia_ab_limite_vendita',
  6 => 'agenzia_max_vendita',
  7 => 'agenzia_ab_max_vendita',
  8 => 'ref_agenzia_datarecord',
  9 => 'agenzia_listini_agenzia_listini_nome',
  10 => 'agenzie_agenzia_tipologia',
);
    private const WRITABLE = array (
  0 => 'agenzia_listini_id',
  1 => 'agenzia_id',
  2 => 'hotel_id',
  3 => 'agenzia_limite_vendita',
  4 => 'agenzia_ab_limite_vendita',
  5 => 'agenzia_max_vendita',
  6 => 'agenzia_ab_max_vendita',
  7 => 'ref_agenzia_datarecord',
);
    private const FILTERABLE = array (
  0 => 'ref_agenzia_listini_id',
  1 => 'agenzia_listini_id',
  2 => 'agenzia_id',
);
    private const SORTABLE = array (
  0 => 'ref_agenzia_listini_id',
  1 => 'agenzia_listini_id',
  2 => 'agenzia_id',
);

    public static function make(object|array $record): array
    {
        if (is_array($record)) {
            $source = $record;
        } elseif (method_exists($record, 'toRawArray')) {
            $source = $record->toRawArray();
        } elseif (method_exists($record, 'toArray')) {
            $source = $record->toArray();
        } else {
            $source = get_object_vars($record);
        }

        return array_intersect_key($source, array_flip(self::READABLE));
    }

    public static function collection(array $records): array
    {
        return array_map(static fn (object|array $record): array => self::make($record), $records);
    }

    public static function writableData(array $data): array
    {
        return array_intersect_key($data, array_flip(self::WRITABLE));
    }

    public static function filterableFields(): array
    {
        return self::FILTERABLE;
    }

    public static function sortableFields(): array
    {
        return self::SORTABLE;
    }
}
