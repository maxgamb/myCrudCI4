<?php

declare(strict_types=1);

namespace App\API\Resources;

/** Serializza la risorsa pratiche_rif secondo la configurazione del Builder. */
final class PraticheRifResource
{
    private const READABLE = array (
  0 => 'pratica_rif_pratica_id',
  1 => 'hotel_id',
  2 => 'pratica_rif_conto_id',
  3 => 'pratica_rif_totale_modificato',
  4 => 'pratica_rif_totale_importo',
  5 => 'pratica_rif_pagamento_importo_pag',
  6 => 'pratica_rif_note',
  7 => 'pratica_rif_out_conto',
  8 => 'pratiche_rif_id',
  9 => 'pratiche_pratica_nome',
);
    private const WRITABLE = array (
  0 => 'pratica_rif_pratica_id',
  1 => 'hotel_id',
  2 => 'pratica_rif_conto_id',
  3 => 'pratica_rif_totale_modificato',
  4 => 'pratica_rif_totale_importo',
  5 => 'pratica_rif_pagamento_importo_pag',
  6 => 'pratica_rif_note',
  7 => 'pratica_rif_out_conto',
  8 => 'pratiche_rif_id',
);
    private const FILTERABLE = array (
  0 => 'pratica_rif_pratica_id',
  1 => 'hotel_id',
  2 => 'pratica_rif_conto_id',
  3 => 'pratiche_rif_id',
);
    private const SORTABLE = array (
  0 => 'pratica_rif_pratica_id',
  1 => 'hotel_id',
  2 => 'pratica_rif_conto_id',
  3 => 'pratiche_rif_id',
);

    public static function make(object|array $record): array
    {
        if (is_array($record)) {
            $source = $record;
        } elseif (method_exists($record, 'toRawArray')) {
            $source = $record->toRawArray();
        } elseif (method_exists($record, 'toArray')) {
            $source = $record->toArray();
        } else {
            $source = get_object_vars($record);
        }

        return array_intersect_key($source, array_flip(self::READABLE));
    }

    public static function collection(array $records): array
    {
        return array_map(static fn (object|array $record): array => self::make($record), $records);
    }

    public static function writableData(array $data): array
    {
        return array_intersect_key($data, array_flip(self::WRITABLE));
    }

    public static function filterableFields(): array
    {
        return self::FILTERABLE;
    }

    public static function sortableFields(): array
    {
        return self::SORTABLE;
    }
}
