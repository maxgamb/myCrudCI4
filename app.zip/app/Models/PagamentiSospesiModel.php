<?php

declare(strict_types=1);

namespace App\Models;

use App\Entities\PagamentiSospesiEntity;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;

/** Model per pagamenti_sospesi; tutte le query del CRUD sono centralizzate qui. */
final class PagamentiSospesiModel extends Model
{
    protected $table = 'pagamenti_sospesi';
    protected $primaryKey = 'pagamento_id';
    protected $returnType = PagamentiSospesiEntity::class;
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = array (
  0 => 'hotel_id',
  1 => 'sospeso_id',
  2 => 'paga_sosp_importo',
  3 => 'data_pagamento',
  4 => 'paga_modalita',
  5 => 'data_rec_paga_sosp',
  6 => 'pagamenti_sospesi_utente_id',
);
    protected $useTimestamps = false;
    protected $skipValidation = true;
    protected $cleanValidationRules = true;

    private const LIST_FILTERS = array (
  'pagamento_id' => 
  array (
    'type' => 'int',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'hotel_id' => 
  array (
    'type' => 'int',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
  'sospeso_id' => 
  array (
    'type' => 'int',
    'operators' => 
    array (
      0 => 'eq',
      1 => 'neq',
      2 => 'gt',
      3 => 'gte',
      4 => 'lt',
      5 => 'lte',
      6 => 'between',
      7 => 'is_null',
      8 => 'not_null',
    ),
  ),
);
    private const SORTABLE_FIELDS = array (
  0 => 'pagamento_id',
  1 => 'hotel_id',
  2 => 'sospeso_id',
);
    private const EXPORT_FIELDS = array (
  0 => 'pagamento_id',
  1 => 'hotel_id',
  2 => 'sospeso_id',
  3 => 'paga_sosp_importo',
  4 => 'data_pagamento',
  5 => 'paga_modalita',
  6 => 'data_rec_paga_sosp',
  7 => 'pagamenti_sospesi_utente_id',
);
    private const RELATION_SEARCHES = array (
  'sospeso_id' => 
  array (
    'table' => 'sospesi',
    'key' => 'sospeso_id',
    'label' => 'sospeso_id',
    'mode' => 'select',
  ),
);
    private const COUNT_CACHE_SECONDS = 60;

    /** Query completa per dettaglio e API. */
    public function baseBuilder(): BaseBuilder
    {
        $builder = $this->db->table('pagamenti_sospesi');
        $builder->select([
            'pagamenti_sospesi.pagamento_id AS pagamento_id',
            'pagamenti_sospesi.hotel_id AS hotel_id',
            'pagamenti_sospesi.sospeso_id AS sospeso_id',
            'pagamenti_sospesi.paga_sosp_importo AS paga_sosp_importo',
            'pagamenti_sospesi.data_pagamento AS data_pagamento',
            'pagamenti_sospesi.paga_modalita AS paga_modalita',
            'pagamenti_sospesi.data_rec_paga_sosp AS data_rec_paga_sosp',
            'pagamenti_sospesi.pagamenti_sospesi_utente_id AS pagamenti_sospesi_utente_id',
            'sospesi__sospeso_id.sospeso_id AS sospesi_sospeso_id'
        ]);
        $builder->join('sospesi AS sospesi__sospeso_id', 'sospesi__sospeso_id.sospeso_id = pagamenti_sospesi.sospeso_id', 'left');
        return $builder;
    }

    /** Query leggera per la tabella Bootstrap AJAX. */
    private function listBuilder(): BaseBuilder
    {
        $builder = $this->db->table('pagamenti_sospesi');
        $builder->select([
            'pagamenti_sospesi.pagamento_id AS pagamento_id',
            'pagamenti_sospesi.hotel_id AS hotel_id',
            'pagamenti_sospesi.sospeso_id AS sospeso_id',
            'pagamenti_sospesi.paga_sosp_importo AS paga_sosp_importo',
            'pagamenti_sospesi.data_pagamento AS data_pagamento',
            'pagamenti_sospesi.paga_modalita AS paga_modalita',
            'pagamenti_sospesi.data_rec_paga_sosp AS data_rec_paga_sosp',
            'pagamenti_sospesi.pagamenti_sospesi_utente_id AS pagamenti_sospesi_utente_id',
            'sospesi__sospeso_id.sospeso_id AS sospesi_sospeso_id'
        ]);
        $builder->join('sospesi AS sospesi__sospeso_id', 'sospesi__sospeso_id.sospeso_id = pagamenti_sospesi.sospeso_id', 'left');
        return $builder;
    }

    /** Conteggio senza JOIN, così i filtri indicizzati restano economici. */
    private function listCountBuilder(): BaseBuilder
    {
        $builder = $this->db->table('pagamenti_sospesi');
        return $builder;
    }

    public function getDetail(int|string $id): ?object
    {
        return $this->baseBuilder()
            ->where('pagamenti_sospesi.pagamento_id', $id)
            ->get()
            ->getRow();
    }

    /**
     * Restituisce una pagina HTML-ready con Pager CI4.
     *
     * @return array{rows: array, total: int, page: int, perPage: int, pagerLinks: string, sort: string, direction: string}
     */
    public function getListPage(
        array $filters,
        int $page = 1,
        int $perPage = 25,
        string $sort = 'pagamento_id',
        string $direction = 'desc'
    ): array {
        $page = max(1, $page);
        $perPage = max(25, min(100, $perPage));
        $sort = in_array($sort, self::SORTABLE_FIELDS, true) ? $sort : 'pagamento_id';
        $direction = strtolower($direction) === 'asc' ? 'ASC' : 'DESC';

        $dataBuilder = $this->listBuilder();
        $countBuilder = $this->listCountBuilder();
        $this->applyListFilters($dataBuilder, $filters, true);
        $this->applyListFilters($countBuilder, $filters, false);

        $total = $this->countListRows($countBuilder, $filters);
        $rows = $dataBuilder
            ->orderBy('pagamenti_sospesi.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();

        $pagerLinks = service('pager')->makeLinks(
            $page,
            $perPage,
            $total,
            'bootstrap_full'
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pagerLinks' => $pagerLinks,
            'sort' => $sort,
            'direction' => strtolower($direction),
        ];
    }

    /** Legge i record di export a blocchi usando la chiave primaria come cursore. */
    public function getExportRows(array $filters, int $limit = 2000, int|string|null $after = null): array
    {
        $builder = $this->db->table('pagamenti_sospesi');
        $builder->select([
            'pagamenti_sospesi.pagamento_id AS pagamento_id',
            'pagamenti_sospesi.hotel_id AS hotel_id',
            'pagamenti_sospesi.sospeso_id AS sospeso_id',
            'pagamenti_sospesi.paga_sosp_importo AS paga_sosp_importo',
            'pagamenti_sospesi.data_pagamento AS data_pagamento',
            'pagamenti_sospesi.paga_modalita AS paga_modalita',
            'pagamenti_sospesi.data_rec_paga_sosp AS data_rec_paga_sosp',
            'pagamenti_sospesi.pagamenti_sospesi_utente_id AS pagamenti_sospesi_utente_id',
            'sospesi__sospeso_id.sospeso_id AS sospesi_sospeso_id'
        ]);
        $builder->join('sospesi AS sospesi__sospeso_id', 'sospesi__sospeso_id.sospeso_id = pagamenti_sospesi.sospeso_id', 'left');
        $this->applyListFilters($builder, $filters, true);

        if ($after !== null && $after !== '') {
            $builder->where('pagamenti_sospesi.pagamento_id >', $after);
        }

        return $builder
            ->orderBy('pagamenti_sospesi.pagamento_id', 'ASC')
            ->limit(max(1, min(5000, $limit)))
            ->get()
            ->getResultArray();
    }

    public function countExportRows(array $filters): int
    {
        $builder = $this->listCountBuilder();
        $this->applyListFilters($builder, $filters, false);

        return $this->countListRows($builder, $filters);
    }

    /** @return list<string> */
    public function exportFields(): array
    {
        return self::EXPORT_FIELDS;
    }

    private function countListRows(BaseBuilder $builder, array $filters): int
    {
        if ($this->hasActiveFilters($filters) || self::COUNT_CACHE_SECONDS === 0) {
            return $builder->countAllResults();
        }

        $cacheKey = 'mycrud_list_total_' . md5($this->table);
        $cache = service('cache');
        $cached = $cache->get($cacheKey);
        if (is_int($cached) || (is_string($cached) && ctype_digit($cached))) {
            return (int) $cached;
        }

        $total = $builder->countAllResults();
        $cache->save($cacheKey, $total, self::COUNT_CACHE_SECONDS);

        return $total;
    }

    private function hasActiveFilters(array $filters): bool
    {
        foreach ($filters as $filter) {
            if (is_array($filter) && trim((string) ($filter['field'] ?? '')) !== '') {
                return true;
            }
        }

        return false;
    }

    public function clearListCountCache(): void
    {
        service('cache')->delete('mycrud_list_total_' . md5($this->table));
    }

    /**
     * Applica il filtro dinamico costruito dall'interfaccia del sito.
     * Campo e operatore vengono sempre verificati contro LIST_FILTERS.
     */
    private function applyListFilters(BaseBuilder $builder, array $filters, bool $qualified): void
    {
        $applied = 0;
        $nextLogic = 'and';
        foreach (array_values($filters) as $filter) {
            if (!is_array($filter)) {
                continue;
            }

            $field = trim((string) ($filter['field'] ?? ''));
            $operator = trim((string) ($filter['operator'] ?? ''));
            if ($field === '' || !isset(self::LIST_FILTERS[$field])) {
                continue;
            }

            $definition = self::LIST_FILTERS[$field];
            $allowedOperators = (array) ($definition['operators'] ?? ['eq']);
            if (!in_array($operator, $allowedOperators, true)) {
                continue;
            }

            $column = $qualified ? 'pagamenti_sospesi.' . $field : $field;
            $value = is_scalar($filter['value'] ?? null) ? trim((string) $filter['value']) : '';
            $valueTo = is_scalar($filter['value_to'] ?? null) ? trim((string) $filter['value_to']) : '';
            // La logica appartiene alla riga precedente e collega la
            // condizione appena applicata a quella successiva nell'interfaccia.
            $logic = $applied > 0 ? $nextLogic : 'and';

            if (!in_array($operator, ['is_null', 'not_null'], true) && $value === '') {
                continue;
            }
            if ($operator === 'between' && $valueTo === '') {
                continue;
            }

            // Ogni condizione è raggruppata: AND/OR resta prevedibile anche
            // per operatori composti come BETWEEN.
            if ($logic === 'or') {
                $builder->orGroupStart();
            } else {
                $builder->groupStart();
            }

            switch ($operator) {
                case 'neq':
                    $builder->where($column . ' !=', $value);
                    break;
                case 'gt':
                    $builder->where($column . ' >', $value);
                    break;
                case 'gte':
                    $builder->where($column . ' >=', $value);
                    break;
                case 'lt':
                    $builder->where($column . ' <', $value);
                    break;
                case 'lte':
                    $builder->where($column . ' <=', $value);
                    break;
                case 'between':
                    $builder->where($column . ' >=', $value)
                        ->where($column . ' <=', $valueTo);
                    break;
                case 'starts_with':
                    $builder->like($column, $value, 'after');
                    break;
                case 'contains':
                    $builder->like($column, $value, 'both');
                    break;
                case 'ends_with':
                    $builder->like($column, $value, 'before');
                    break;
                case 'is_null':
                    $builder->where($column, null);
                    break;
                case 'not_null':
                    $builder->where($column . ' IS NOT NULL', null, false);
                    break;
                case 'eq':
                default:
                    $builder->where($column, $value);
                    break;
            }

            $builder->groupEnd();
            $applied++;
            $nextLogic = strtolower((string) ($filter['logic'] ?? 'and')) === 'or' ? 'or' : 'and';
        }
    }

    /** Elenco REST paginato con whitelist di filtri e ordinamento. */
    public function apiList(array $query, array $filterable, array $sortable): array
    {
        $page = max(1, (int) ($query['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($query['perPage'] ?? 25)));
        $builder = $this->baseBuilder();

        foreach ((array) ($query['filter'] ?? []) as $field => $value) {
            if (is_scalar($value) && in_array($field, $filterable, true) && (string) $value !== '') {
                $builder->where('pagamenti_sospesi.' . $field, $value);
            }
        }

        $sort = (string) ($query['sort'] ?? 'pagamento_id');
        $sort = in_array($sort, $sortable, true) ? $sort : 'pagamento_id';
        $direction = strtolower((string) ($query['direction'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $total = (clone $builder)->countAllResults(false);
        $rows = $builder->orderBy('pagamenti_sospesi.' . $sort, $direction)
            ->limit($perPage, ($page - 1) * $perPage)
            ->get()
            ->getResult();
        $pageCount = max(1, (int) ceil($total / $perPage));

        return [
            'rows' => $rows,
            'meta' => [
                'page' => $page,
                'perPage' => $perPage,
                'total' => $total,
                'pageCount' => $pageCount,
            ],
            'links' => [
                'self' => $this->apiLink($query, $page),
                'next' => $page < $pageCount ? $this->apiLink($query, $page + 1) : null,
                'prev' => $page > 1 ? $this->apiLink($query, $page - 1) : null,
            ],
        ];
    }

    private function apiLink(array $query, int $page): string
    {
        $query['page'] = $page;
        return current_url() . '?' . http_build_query($query);
    }
    /** Restituisce le opzioni della relazione sospeso_id. */
    public function getSospesiSospesoIdOptions(): array
    {
        return $this->db->table('sospesi')
            ->select(['sospeso_id', 'sospeso_id'])
            ->orderBy('sospeso_id', 'ASC')
            ->get()
            ->getResult();
    }
    public function relationOptions(): array
    {
        return [
            'sospeso_id' => $this->toOptions($this->getSospesiSospesoIdOptions(), 'sospeso_id', 'sospeso_id'),
        ];
    }

    /**
     * Ricerca server-side delle opzioni per relazioni grandi.
     * Tabella, chiave e campo label arrivano solo dalla whitelist generata.
     *
     * @return list<array{id:string,text:string}>
     */
    public function searchRelationOptions(string $field, string $query, int $limit = 20): array
    {
        if (!isset(self::RELATION_SEARCHES[$field])) {
            return [];
        }

        $definition = self::RELATION_SEARCHES[$field];
        $limit = max(1, min(100, $limit));
        $builder = $this->db->table((string) $definition['table'])
            ->select([(string) $definition['key'], (string) $definition['label']])
            ->orderBy((string) $definition['label'], 'ASC')
            ->limit($limit);

        $query = trim($query);
        if ($query !== '') {
            $builder->like((string) $definition['label'], $query, 'after');
        }

        $rows = $builder->get()->getResultArray();
        $result = [];
        foreach ($rows as $row) {
            $result[] = [
                'id' => (string) ($row[(string) $definition['key']] ?? ''),
                'text' => (string) ($row[(string) $definition['label']] ?? ''),
            ];
        }

        return $result;
    }

    private function toOptions(array $rows, string $key, string $label): array
    {
        $options = [];
        foreach ($rows as $row) {
            $options[(string) $row->{$key}] = (string) $row->{$label};
        }
        return $options;
    }

    public function loadHasMany(int|string $parentId): array
    {
        $result = [];

        return $result;
    }

}
